import json

from openai import AzureOpenAI


class GPT4oAzureClientManager:
    def __init__(self,model_name = "gpt-4o"):
        self.api_key = "ae626b4be63b4a3b8f418a9904a33366"
        self.api_url = "https://aoai-t2ea-eastus.openai.azure.com"
        self.api_version = "2024-05-01-preview"
        self.model_name = model_name
        self.embedding_model_name = "text-embedding-3-large"

        self.openai_client = self.__initialize_client()

    def __initialize_client(self):
        """Initialize the OpenAI client."""
        openai_client = AzureOpenAI(
            api_version=self.api_version,
            azure_endpoint=self.api_url,
            api_key=self.api_key,
        )
        return openai_client

    def query_gpt_4o(self, input_prompt):
        """Query GPT-4o with a simple prompt."""
        response = self.openai_client.chat.completions.create(
            model=self.model_name,
            messages=[{"role": "user", "content": input_prompt}],
            temperature=0,
            seed=1,
        )
        return response.choices[0].message.content

    def query_gpt_4o_json(self, input_prompt):
        """Query GPT-4o and get the response in JSON format."""
        response = self.openai_client.chat.completions.create(
            model=self.model_name,
            messages=[{"role": "user", "content": input_prompt}],
            response_format={"type": "json_object"},
            temperature=0,
            seed=1,
        )

        return json.loads(response.choices[0].message.content)

    def generate_embedding(self, text):
        """Generate an embedding for a given text using GPT-4o."""
        response = self.openai_client.embeddings.create(input=[text],
                                                        model=self.embedding_model_name)
        return response.data[0].embedding
