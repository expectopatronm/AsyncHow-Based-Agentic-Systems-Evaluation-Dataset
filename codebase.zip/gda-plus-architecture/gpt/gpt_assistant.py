from datetime import datetime, timedelta
from gpt.gpt_client import GPT4oAzureClientManager


class GPT4oAssistantManager:
    def __init__(self, instruction):
        self.openai_client = GPT4oAzureClientManager().openai_client
        self.model_name = GPT4oAzureClientManager().model_name
        self.openai_assistant = self.__initialize_assistant(instruction)
        self.session_active_until = None
        self.current_thread = None

    def __initialize_assistant(self, instruction):
        """Initialize the AI assistant."""
        assistant = self.openai_client.beta.assistants.create(
            instructions=instruction,
            model=self.model_name,
            tools=[{"type": "code_interpreter"}]
        )
        return assistant

    def __is_session_active(self):
        """Check if the current session is still active."""
        if self.session_active_until and datetime.now() < self.session_active_until:
            return True
        return False

    def __start_new_session(self):
        """Start a new session and update the session expiration time."""
        self.current_thread = self.openai_client.beta.threads.create()
        self.session_active_until = datetime.now() + timedelta(hours=1)

    def query_with_code_interpreter(self, input_prompt):
        """Query the assistant with the code interpreter tool."""
        if not self.__is_session_active():
            self.__start_new_session()

        message = self.openai_client.beta.threads.messages.create(
            thread_id=self.current_thread.id,
            role="user",
            content=input_prompt
        )
        run = self.openai_client.beta.threads.runs.create_and_poll(
            thread_id=self.current_thread.id,
            assistant_id=self.openai_assistant.id,
        )
        if run.status == 'completed':
            messages = self.openai_client.beta.threads.messages.list(
                thread_id=self.current_thread.id
            )
            return messages
        else:
            return run.status
