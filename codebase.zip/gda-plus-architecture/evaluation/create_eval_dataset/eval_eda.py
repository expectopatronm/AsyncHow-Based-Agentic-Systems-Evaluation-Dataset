import pandas as pd

df = pd.read_csv('eval_data_seq_df.csv')
#df = df.drop(columns=['Unnamed: 0'])
print()


