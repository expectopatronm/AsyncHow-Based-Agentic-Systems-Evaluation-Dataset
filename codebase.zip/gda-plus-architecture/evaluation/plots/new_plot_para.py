import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pearsonr



def plot_boxes():
    # Prepare the data for plotting
    data = pd.read_csv('../test_data/refined_metrics_df_para_final_50.csv')
    data_to_plot = data[['Category', 'Answer Score', 'Tool F1 Score', 'Structural Similarity Index']].dropna()

    # Set up the matplotlib figure
    plt.figure(figsize=(18, 6))

    # Plot 1: Answer Score by Category
    plt.subplot(1, 3, 1)
    sns.boxplot(data=data_to_plot, x='Category', y='Answer Score')
    plt.title('Answer Score by Category')
    plt.xlabel('Category')
    plt.ylabel('Answer Score')

    # Plot 2: Tool F1 Score by Category
    plt.subplot(1, 3, 2)
    sns.boxplot(data=data_to_plot, x='Category', y='Tool F1 Score')
    plt.title('Tool F1 Score by Category')
    plt.xlabel('Category')
    plt.ylabel('Tool F1 Score')

    # Plot 3: Structural Similarity Index by Category
    plt.subplot(1, 3, 3)
    sns.boxplot(data=data_to_plot, x='Category', y='Structural Similarity Index')
    plt.title('Structural Similarity Index by Category')
    plt.xlabel('Category')
    plt.ylabel('Structural Similarity Index')

    # Adjust layout to prevent overlap
    plt.tight_layout()
    plt.savefig('new_plot_para/plot_boxes_by_category.png')

    # Show the plot
    #plt.show()

def calculate_p_values(df):
    """Calculates the p-values for the correlation matrix."""
    df = df.dropna()  # Drop missing values for accurate correlation calculation
    p_values = pd.DataFrame(np.zeros((df.shape[1], df.shape[1])), columns=df.columns, index=df.columns)
    for col1 in df.columns:
        for col2 in df.columns:
            if col1 != col2:
                _, p_value = pearsonr(df[col1], df[col2])
                p_values.loc[col1, col2] = p_value
            else:
                p_values.loc[col1, col2] = np.nan  # No p-value for correlation with self
    return p_values


def plot_correlation_heatmap(data, columns_of_interest):
    """Plots a correlation heatmap with p-values annotated."""
    # Select the relevant columns and remove any columns that are all zeros
    data_subset = data[columns_of_interest].loc[:, (data != 0).any(axis=0)]

    data_subset.to_csv("data_subset_metrics_df_para_final_50.csv")

    # Calculate correlation matrix and p-value matrix
    correlation_matrix = data_subset.corr()
    p_value_matrix = calculate_p_values(data_subset)

    # Plot the correlation heatmap with p-values annotated
    plt.figure(figsize=(12, 10))
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5, mask=p_value_matrix > 0.05)
    plt.title("Correlation Heatmap with P-values (insignificant correlations masked)")
    #plt.show()
    plt.savefig('new_plot_para/plot_correlation_heatmap.png')


def plot_scatter_with_regression(data):
    """Plots multiple scatter plots with regression lines and p-value annotations in a single figure."""
    # Calculate the number of rows needed based on the number of pairs
    metrics_pairs = [
        ('Node F1 Score', 'Structural Similarity Index'),
        ('Tool F1 Score', 'Answer Score')
    ]

    n_pairs = len(metrics_pairs)
    n_cols = 2  # Adjust this if you want more/less columns
    n_rows = (n_pairs + 1) // n_cols  # Calculate the number of rows needed


    # Create a figure with subplots
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(12, 6 * n_rows))

    # If there's only one row, axes will not be a 2D array, so we ensure it's treated as such
    if n_rows == 1:
        axes = np.array([axes])

    for i, (x_metric, y_metric) in enumerate(metrics_pairs):
        # Skip pairs with all zero values
        if data[x_metric].sum() == 0 or data[y_metric].sum() == 0:
            print(f"Skipping plot for {x_metric} vs. {y_metric} due to all zero values.")
            continue

        # Calculate correlation and p-value
        corr, p_value = pearsonr(data[x_metric], data[y_metric])

        # Determine the position in the subplot grid
        row = i // n_cols
        col = i % n_cols

        # Plot the scatter with regression line on the appropriate subplot
        sns.regplot(data=data, x=x_metric, y=y_metric, ax=axes[row, col])
        axes[row, col].set_title(f"{x_metric} vs. {y_metric} (p-value: {p_value:.3f})")
        axes[row, col].set_xlabel(x_metric)
        axes[row, col].set_ylabel(y_metric)

    # Adjust layout for better spacing between plots
    plt.tight_layout()

    # Save the figure if needed
    plt.savefig('new_plot_para/combined_plots.png')
    plt.show()


# Example usage with your dataset
data = pd.read_csv('../test_data/refined_metrics_df_para_final_50.csv')

# List of metrics to include in the analysis
columns_of_interest = [
    'Node F1 Score', 'Structural Similarity Index', 'Tool F1 Score',
    'Answer Score', 'Graph Edit Distance', 'Node Precision', 'Node Recall'
]

# Plot correlation heatmap with p-values
plot_correlation_heatmap(data, columns_of_interest)

plot_scatter_with_regression(data)
plot_boxes()
