import pandas as pd
import numpy as np
from scipy import stats
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
import os


def load_and_preprocess_data(file_path):
    data = pd.read_csv(file_path, index_col=0)
    return data.dropna()


def analyze_correlations(data, features, target='Answer Score'):
    correlations = []
    for feature in features:
        corr, p_value = stats.pearsonr(data[feature], data[target])
        correlations.append({
            'Feature': feature,
            'Correlation': corr,
            'P-value': p_value
        })
    return pd.DataFrame(correlations).sort_values('Correlation', ascending=False)


def plot_correlations(correlations, title, save_path):
    plt.figure(figsize=(12, 6))
    sns.barplot(x='Feature', y='Correlation', data=correlations)
    plt.xticks(rotation=45, ha='right')
    plt.title(title)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def plot_regression(data, x, y, title, save_path):
    plt.figure(figsize=(10, 6))
    sns.regplot(data=data, x=x, y=y, scatter_kws={'alpha': 0.5}, line_kws={'color': 'red'})
    plt.title(title)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def main():
    # Create 'plots_claude' directory if it doesn't exist
    os.makedirs('plots_claude', exist_ok=True)

    # Load datasets
    seq_data = load_and_preprocess_data('../test_data/refined_metrics_df_seq_final_50.csv')
    para_data = load_and_preprocess_data('../test_data/refined_metrics_df_para_final_50.csv')

    features = [
        'Structural Similarity Index', 'Node Label Similarity', 'Edge Precision',
        'Edge F1 Score', 'Expected Task Complexity', 'Tool Precision', 'Tool Recall',
        'Tool F1 Score', 'Path Length Similarity', 'Graph Edit Distance'
    ]

    for task_type, data in [("Sequential", seq_data), ("Parallel", para_data)]:
        print(f"\n{task_type} Tasks Analysis:")

        correlations = analyze_correlations(data, features)
        print("Correlations with Answer Score:")
        print(correlations)

        plot_correlations(correlations,
                          f'{task_type} Tasks: Feature Correlations with Answer Score',
                          f'plots_claude/{task_type.lower()}_correlations.png')

        # Plot regression plots for top 3 correlated features
        top_features = correlations.head(3)['Feature'].tolist()
        for feature in top_features:
            plot_regression(data, feature, 'Answer Score',
                            f'{task_type} Tasks: {feature} vs Answer Score',
                            f'plots_claude/{task_type.lower()}_{feature.replace(" ", "_").lower()}_vs_answer_score.png')

        # Multiple linear regression
        X = data[features]
        y = data['Answer Score']
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        model = LinearRegression()
        model.fit(X_scaled, y)

        # Feature importance
        importance = pd.DataFrame({
            'Feature': features,
            'Importance': abs(model.coef_)
        }).sort_values('Importance', ascending=False)
        print("\nFeature Importance:")
        print(importance)

        # R-squared
        r_squared = model.score(X_scaled, y)
        print(f"\nR-squared: {r_squared:.4f}")


if __name__ == "__main__":
    main()