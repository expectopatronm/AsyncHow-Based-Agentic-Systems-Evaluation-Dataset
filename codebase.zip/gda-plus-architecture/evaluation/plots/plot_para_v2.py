# Creating a figure with 2x2 subplots for the correlation plots

import matplotlib.pyplot as plt
import seaborn as sns
import pandas  as pd


fig, axs = plt.subplots(2, 2, figsize=(16, 12))

df_clean = pd.read_csv('../test_data/refined_metrics_df_para_final_50.csv')

# Plot: Tool Recall vs Answer Score
sns.regplot(x='Tool Recall', y='Answer Score', data=df_clean, scatter_kws={'s':50}, line_kws={'color':'red'}, ax=axs[0, 0])
axs[0, 0].set_title('Tool Recall vs Answer Score')
axs[0, 0].set_xlabel('Tool Recall')
axs[0, 0].set_ylabel('Answer Score')

# Plot: Structural Similarity Index vs Answer Score
sns.regplot(x='Structural Similarity Index', y='Answer Score', data=df_clean, scatter_kws={'s':50}, line_kws={'color':'green'}, ax=axs[0, 1])
axs[0, 1].set_title('Structural Similarity Index vs Answer Score')
axs[0, 1].set_xlabel('Structural Similarity Index')
axs[0, 1].set_ylabel('Answer Score')

# Plot: Graph Edit Distance vs Execution Time
sns.regplot(x='Graph Edit Distance', y='Execution Time', data=df_clean, scatter_kws={'s':50}, line_kws={'color':'blue'}, ax=axs[1, 0])
axs[1, 0].set_title('Graph Edit Distance vs Execution Time')
axs[1, 0].set_xlabel('Graph Edit Distance')
axs[1, 0].set_ylabel('Execution Time')

# Plot: Path Length Similarity vs Expected Task Complexity
sns.regplot(x='Path Length Similarity', y='Expected Task Complexity', data=df_clean, scatter_kws={'s':50}, line_kws={'color':'purple'}, ax=axs[1, 1])
axs[1, 1].set_title('Path Length Similarity vs Expected Task Complexity')
axs[1, 1].set_xlabel('Path Length Similarity')
axs[1, 1].set_ylabel('Expected Task Complexity')

# Adjust layout for better spacing
plt.tight_layout(pad=3.0)
plt.savefig('new_plot_para/plot_para_all_important_metrics.png')
plt.show()