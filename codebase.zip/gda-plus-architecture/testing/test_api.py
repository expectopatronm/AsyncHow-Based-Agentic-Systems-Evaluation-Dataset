import asyncio
import websockets
import json


async def test_websocket():
    uri = "ws://localhost:8000/ws/process_query_with_feedback"

    # Establish connection to the WebSocket server
    async with websockets.connect(uri) as websocket:
        # Send the query in JSON format
        query = {
            "user_query": "I would like to set the temperature in my car to two degrees more than the current temperature in Munich. "
                          "I would also like to know the current weather in Berlin."
        }
        await websocket.send(json.dumps(query))

        # Listen for feedback and final response
        while True:
            try:
                message = await websocket.recv()
                print(f"Received message: {message}")
            except websockets.ConnectionClosed:
                print("Connection closed")
                break


# Run the test
asyncio.run(test_websocket())
