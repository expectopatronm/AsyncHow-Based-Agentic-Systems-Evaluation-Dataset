import os
import sys
import unittest
import threading
import time

# Get the directory of the current script
script_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
sys.path.append(script_dir)

from pipeline import Pipeline


class TestPipelineFeedback(unittest.TestCase):

    def setUp(self):
        """
        Set up the pipeline with feedback generation enabled.
        """
        self.pipeline = Pipeline(semantic_tool_filtering=False, include_indirect_dependencies=False,
                                 generate_feedback=True)
        self.user_query = (
            "I would like to set the temperature in my car to two degrees more than the current temperature in Munich. "
            "I would also like to know the current weather in Berlin.")
        self.pipeline.configure_for_query(self.user_query)

    def test_feedback_queue_populates_while_task_running(self):
        """
        Test that feedback is being populated in the queue while the task is executing.
        """

        def run_pipeline():
            self.pipeline.execute_pipeline(self.user_query)

        pipeline_thread = threading.Thread(target=run_pipeline)
        pipeline_thread.start()

        feedback_received = False
        while pipeline_thread.is_alive():
            if not self.pipeline.feedback_system.task_execution_metadata.empty():
                feedback = self.pipeline.feedback_system.task_execution_metadata.get()
                print(f"Feedback received: {feedback}")
                self.assertIn('feedback_phrase', feedback)  # Ensure feedback contains the phrase
                feedback_received = True
            time.sleep(0.25)

        pipeline_thread.join()  # Ensure pipeline finishes execution
        self.assertTrue(feedback_received, "No feedback was generated while the task was running")

    def test_feedback_occurs_before_task_completion(self):
        """
        Ensure that feedback is generated before the final result is produced.
        """
        feedback_timestamps = []
        task_end_time = None

        def run_pipeline():
            nonlocal task_end_time
            self.pipeline.execute_pipeline(self.user_query)
            task_end_time = time.time()

        pipeline_thread = threading.Thread(target=run_pipeline)
        pipeline_thread.start()

        while pipeline_thread.is_alive():
            if not self.pipeline.feedback_system.task_execution_metadata.empty():
                feedback_timestamps.append(time.time())
            time.sleep(0.25)

        pipeline_thread.join()

        # Ensure feedback occurred before task completion
        self.assertIsNotNone(task_end_time, "Pipeline did not finish executing")
        for timestamp in feedback_timestamps:
            self.assertLess(timestamp, task_end_time, "Feedback was generated after task execution finished")

    def test_feedback_and_task_execution_parallelism(self):
        """
        Test that feedback generation happens in parallel with task execution.
        """
        feedback_timestamps = []
        task_end_time = None

        def run_pipeline():
            nonlocal task_end_time
            self.pipeline.execute_pipeline(self.user_query)
            task_end_time = time.time()

        pipeline_thread = threading.Thread(target=run_pipeline)
        pipeline_thread.start()

        while pipeline_thread.is_alive():
            if not self.pipeline.feedback_system.task_execution_metadata.empty():
                feedback_timestamps.append(time.time())
            time.sleep(0.25)

        pipeline_thread.join()

        # Check if feedback was received in parallel
        if feedback_timestamps:
            final_feedback_received_time = feedback_timestamps[-1]
            self.assertLess(final_feedback_received_time, task_end_time,
                            "Feedback generation did not occur in parallel with task execution")

    def test_feedback_content_uniqueness(self):
        """
        Test that feedback phrases are unique and not repeated during the task execution.
        """
        feedback_phrases = set()

        def run_pipeline():
            self.pipeline.execute_pipeline(self.user_query)

        pipeline_thread = threading.Thread(target=run_pipeline)
        pipeline_thread.start()

        while pipeline_thread.is_alive():
            if not self.pipeline.feedback_system.task_execution_metadata.empty():
                feedback = self.pipeline.feedback_system.task_execution_metadata.get()
                phrase = feedback['feedback_phrase']
                self.assertNotIn(phrase, feedback_phrases, "Feedback phrase is repeated")
                feedback_phrases.add(phrase)
            time.sleep(0.25)

        pipeline_thread.join()

    def test_feedback_queue_is_cleared_before_execution(self):
        """
        Test that the feedback queue is cleared before each new task execution begins.
        """
        # Insert some data in the feedback queue
        self.pipeline.feedback_system.task_execution_metadata.put(
            {"task_id": "test", "feedback_phrase": "Old Feedback"})

        def run_pipeline():
            self.pipeline.configure_for_query(self.user_query)
            self.pipeline.execute_pipeline(self.user_query)

        self.assertFalse(self.pipeline.feedback_system.task_execution_metadata.empty(),
                         "Feedback queue was not prefilled properly")

        pipeline_thread = threading.Thread(target=run_pipeline)
        pipeline_thread.start()

        while pipeline_thread.is_alive():
            time.sleep(0.25)

        pipeline_thread.join()

        # Ensure old feedback is cleared and replaced with new feedback
        self.assertTrue(self.pipeline.feedback_system.task_execution_metadata.empty(),
                        "Feedback queue was not cleared before execution")


if __name__ == '__main__':
    unittest.main()
