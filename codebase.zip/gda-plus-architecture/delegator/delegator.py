import logging


class Delegator:
    """
    A class that delegates tasks to appropriate tools/functions,
    executes them, and manages the task graph execution.
    """

    def __init__(self, my_gpt_client_manager, timing_profiler=None):
        """
        Initializes the Delegator instance.

        Attributes:
            client (object): Instance of GPT4oAzureClientManager for API interaction.
            deployment_name (str): Name of the deployment/model used by the client.
            delegation_results (dict): A dictionary to store the results of task delegations.
        """
        my_gpt_client_manager = my_gpt_client_manager

        self.client = my_gpt_client_manager.openai_client
        self.deployment_name = my_gpt_client_manager.model_name
        self.timing_profiler = timing_profiler

        self.task_graph = None
        self.tool_manager = None
        self.executor = None
        self.delegation_results = {}

    def initialize_task_graph(self, task_graph):
        """Initializes the task graph for execution."""
        logging.info("Initializing task graph.")
        self.task_graph = task_graph

    def initialize_executor(self, executor):
        """Initializes the executor."""
        logging.info("Initializing Executor.")
        self.executor = executor

    def execute_task_graph(self, execution_mode='parallel'):
        """
        Executes the task graph using the specified execution mode (parallel or sequential).

        Args:
            execution_mode (str): The mode of execution ('parallel' or 'sequential').

        Returns:
            dict: A dictionary containing the results of each task.
        """
        if self.timing_profiler:
            self.timing_profiler.start_task_graph_execution_timing()

        logging.info(f"Executing task graph in {execution_mode} mode.")

        if execution_mode == 'parallel':
            self.delegation_results = self.executor.execute_task_graph_parallely()
        else:
            self.delegation_results = self.executor.execute_task_graph_sequentially()

        if self.timing_profiler:
            self.timing_profiler.stop_task_graph_execution_timing()

        logging.info("Task graph execution completed.")
        return self.delegation_results

    def consolidate_tasks(self, user_query):
        """
        Consolidates the results of the executed tasks into a final response.

        Args:
            user_query (str): The original user query.

        Returns:
            str: The final consolidated response.
        """

        if self.timing_profiler:
            self.timing_profiler.start_consolidation_timing()

        logging.info("Consolidating task results into final response.")

        prompt = """
                You are an assistant operating within a larger LLM-based Agentic Architecture. 
                This architecture is designed to answer user queries through a divide-and-conquer approach.
                Your role is to generate a final response to the user's query by considering the results of multiple tasks.
                These tasks were generated from the user's query using a task graph that ensures no cyclic dependencies.
                Each task result must be taken into account to form a comprehensive and concise response.
                Ensure that the final response addresses all aspects of the user's query and is within 50 words.
                """

        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": f'User Query: {user_query}'}
        ]

        for key, value in self.delegation_results.items():
            task_description = next(node['label'] for node in self.task_graph['nodes'] if node['id'] == key)
            messages.append({"role": "assistant", "content": f'Task: {task_description}\nResult: {value["result"]}'})

        self.delegation_results.clear()

        final_response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=messages,
        )

        if self.timing_profiler:
            self.timing_profiler.stop_consolidation_timing()

        logging.info("Final response generated.")
        return final_response.choices[0].message.content
