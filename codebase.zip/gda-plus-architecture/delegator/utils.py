import os
import sys
import subprocess

import json
from datetime import datetime


def execute_function_locally(folder_path, *args, **kwargs):
    """
    Execute a function defined in a Python file with locally installed dependencies on Windows.

    Args:
        folder_path (str): The path to the folder containing the .py file and optionally requirements.txt.
        *args: Positional arguments to pass to the function.
        **kwargs: Keyword arguments to pass to the function.

    Returns:
        The output of the executed function.

    Raises:
        subprocess.CalledProcessError: If any subprocess call (e.g., pip install) fails.
    """
    folder_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', folder_path)

    if not os.path.exists(folder_path):
        raise ValueError(f"The folder '{folder_path}' does not exist.")

    py_file = None
    requirements_file = None

    for filename in os.listdir(folder_path):
        if filename.endswith('.py'):
            py_file = os.path.join(folder_path, filename)
        elif filename == 'requirements.txt':
            requirements_file = os.path.join(folder_path, filename)

    if not py_file:
        raise ValueError(f"No .py file found in '{folder_path}'")

    if requirements_file:
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', requirements_file])
        except subprocess.CalledProcessError as e:
            raise subprocess.CalledProcessError(e.returncode, e.cmd,
                                                f"Failed to install requirements from {requirements_file}")

    try:
        sys.path.insert(0, os.path.dirname(py_file))
        module_name = os.path.splitext(os.path.basename(py_file))[0]
        module = __import__(module_name)

        func_to_call = getattr(module, module_name)
        function_output = func_to_call(*args, **kwargs)

        return function_output

    except Exception as e:
        raise RuntimeError(f'Function failed to execute: Error: {e}')


def execute_function_in_virtualenv(folder_path, *args, **kwargs):
    """
    Execute a function defined in a Python file within a virtual environment on Windows.

    Args:
        folder_path (str): The path to the folder containing the .py file and optionally requirements.txt.
        *args: Positional arguments to pass to the function.
        **kwargs: Keyword arguments to pass to the function.

    Returns:
        The output of the executed function.

    Raises:
        subprocess.CalledProcessError: If any subprocess call (e.g., venv creation, pip install) fails.
    """
    folder_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', folder_path)

    if not os.path.exists(folder_path):
        raise ValueError(f"The folder '{folder_path}' does not exist.")

    py_file = None
    requirements_file = None

    for filename in os.listdir(folder_path):
        if filename.endswith('.py'):
            py_file = os.path.join(folder_path, filename)
        elif filename == 'requirements.txt':
            requirements_file = os.path.join(folder_path, filename)

    if not py_file:
        raise ValueError(f"No .py file found in '{folder_path}'")

    function_name = os.path.splitext(os.path.basename(py_file))[0]
    venv_name = f"{function_name}_venv"
    venv_dir = os.path.join(folder_path, venv_name)

    if not os.path.exists(venv_dir):
        try:
            python_executable = sys.executable
            subprocess.check_call([python_executable, '-m', 'venv', venv_dir])
            venv_pip = os.path.join(venv_dir, 'Scripts', 'pip.exe')

            if requirements_file:
                subprocess.check_call([venv_pip, 'install', '-r', requirements_file])

        except subprocess.CalledProcessError as e:
            raise subprocess.CalledProcessError(e.returncode, e.cmd,
                                                f"Failed to setup virtual environment for {function_name}")

    try:
        sys.path.insert(0, os.path.dirname(py_file))
        module_name = os.path.splitext(os.path.basename(py_file))[0]
        module = __import__(module_name)

        func_to_call = getattr(module, function_name)
        function_output = func_to_call(*args, **kwargs)

        return function_output

    except Exception as e:
        raise RuntimeError(f'Function failed to execute: Error: {e}')


def post_process_function_response(response):
    """
    Converts the function response to a JSON string if it's a dictionary.

    Args:
        response (dict): The response object to convert.

    Returns:
        str: JSON string of the response if it's a dictionary, otherwise returns the response unchanged.
    """
    return json.dumps(response) if isinstance(response, dict) else response


def get_current_datetime():
    """
    Returns the current date and time in the format:
    "Today is {Day of the Week}, {YYYY-MM-DD}, {HH:MM}"

    Returns:
        str: A string with the current date and time.
    """
    # Get the current date and time
    now = datetime.now()

    # Format the date and time as requested
    formatted_date_time = now.strftime("Today is %A, %Y-%m-%d, %H:%M")

    return formatted_date_time


def get_current_location():
    """
    Returns the current location.

    This function determines the current geographic location of the user
    and returns it as a string.

    Returns:
        str: The current location.
    """
    return "You are located in Munich, Oskar-Schlemmer-Strasse 19."
