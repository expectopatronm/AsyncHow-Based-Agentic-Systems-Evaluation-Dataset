import os

from collections import defaultdict
from datetime import datetime

import matplotlib

matplotlib.use('Agg')
import matplotlib.ticker as ticker
import matplotlib.pyplot as plt
import graphviz


def wrap_label_text(text, width=20):
    """
    Wrap text for Graphviz label to fit within a specified width.

    Args:
        text (str): The text to wrap.
        width (int, optional): The width to wrap the text (default is 20).

    Returns:
        str: The wrapped text.
    """
    import textwrap
    return "<BR/>".join(textwrap.fill(text, width).split('\n'))

def plot_task_graph_with_query_num(task_data,query_num,fontname='Courier'):
    """
    Generate and save a visualization of a task graph using Graphviz.

    This function creates a directed graph (Digraph) using Graphviz based on the provided task data.
    Nodes and edges are added to the graph based on the 'nodes' and 'edges' attributes in the task_data dictionary.
    The resulting graph is rendered and saved as 'task_graph.png' in the current working directory.

    Args:
        task_data (dict): A dictionary containing 'nodes' and 'edges' representing the task graph. Each node should have 'id', 'label', and optionally 'user_inputs'.
        fontname (str, optional): The name of the font to use for the text in the nodes (default is 'Courier').

    Returns:
        graphviz.Digraph: The Graphviz Digraph object representing the task graph.
    """
    dot = graphviz.Digraph(comment='Task Graph')

    for node in task_data['nodes']:
        label = wrap_label_text(node['label'])
        if 'user_inputs' in node:
            label += f"<BR/>User Inputs:<BR/>{format_user_inputs(node['user_inputs'])}"
        dot.node(node['id'],
                 label=f'<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4"><TR><TD>{label}</TD></TR></TABLE>>',
                 shape='rect', fontname=fontname)

    for edge in task_data['edges']:
        dot.edge(edge['from'], edge['to'], fontname=fontname)

    dot.render(os.path.join(os.path.dirname(__file__),'outputs','task_graph', str("query_"+ query_num)), format='png')
    return dot


def plot_task_graph(task_data, fontname='Courier'):
    """
    Generate and save a visualization of a task graph using Graphviz.

    This function creates a directed graph (Digraph) using Graphviz based on the provided task data.
    Nodes and edges are added to the graph based on the 'nodes' and 'edges' attributes in the task_data dictionary.
    The resulting graph is rendered and saved as 'task_graph.png' in the current working directory.

    Args:
        task_data (dict): A dictionary containing 'nodes' and 'edges' representing the task graph. Each node should have 'id', 'label', and optionally 'user_inputs'.
        fontname (str, optional): The name of the font to use for the text in the nodes (default is 'Courier').

    Returns:
        graphviz.Digraph: The Graphviz Digraph object representing the task graph.
    """
    dot = graphviz.Digraph(comment='Task Graph')

    for node in task_data['nodes']:
        label = wrap_label_text(node['label'])
        if 'user_inputs' in node:
            label += f"<BR/>User Inputs:<BR/>{format_user_inputs(node['user_inputs'])}"
        dot.node(node['id'],
                 label=f'<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4"><TR><TD>{label}</TD></TR></TABLE>>',
                 shape='rect', fontname=fontname)

    for edge in task_data['edges']:
        dot.edge(edge['from'], edge['to'], fontname=fontname)

    dot.render(os.path.join(os.path.dirname(__file__),
                            'outputs',
                            'task_graph'), format='png')

    return dot


def plot_execution_timings(execution_timings, output_file='execution_timings.png'):
    """
    Plots a horizontal bar chart based on the execution timings of tasks and saves it as a PNG file.

    Args:
        execution_timings (dict): A dictionary containing task execution timings.
            Each key is a task ID, and each value is a dictionary with:
                - "start_time": Start time of the task (timestamp).
                - "end_time": End time of the task (timestamp).
                - "duration": Duration of the task (in seconds).
        output_file (str): The name of the output file to save the chart. Default is 'execution_timings.png'.
    """
    fig, ax = plt.subplots()

    for i, (task_id, timing) in enumerate(execution_timings.items()):
        duration = timing["duration"]

        ax.barh(task_id, duration, left=timing["start_time"], height=0.4, align='center', edgecolor='black')

    ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: datetime.fromtimestamp(x).strftime('%H:%M:%S.%f')))

    plt.xticks(rotation=45)
    ax.set_xlabel('Time')
    ax.set_ylabel('Tasks')
    ax.set_title('Task Execution Timings')

    plt.tight_layout()
    plt.savefig(os.path.join(os.path.dirname(__file__),
                             'outputs',
                             output_file))
    plt.close()


def format_user_inputs(user_inputs):
    """
    Format user inputs as a string for display in the graph node label.

    Args:
        user_inputs (dict): Dictionary containing user input parameters.

    Returns:
        str: Formatted string representation of user inputs.
    """
    formatted_inputs = []
    for key, value in user_inputs.items():
        if value is None:
            value_str = "None"
        elif isinstance(value, list):
            value_str = ', '.join(value)
        else:
            value_str = str(value)
        formatted_inputs.append(f"{key}: {value_str}")
    return '\n'.join(formatted_inputs)


def is_valid_task_graph_response_format(response):
    """
    Check if the given response adheres to the specified format.

    Args:
        response (dict): A dictionary representing the response structure.

    Returns:
        bool: True if the response is in the specified format, False otherwise.
    """
    if not isinstance(response, dict):
        return False

    if 'task_graph' not in response:
        return False

    task_graph = response['task_graph']

    if not isinstance(task_graph, dict):
        return False

    if 'nodes' not in task_graph or 'edges' not in task_graph:
        return False

    nodes = task_graph['nodes']
    edges = task_graph['edges']

    if not isinstance(nodes, list) or not isinstance(edges, list):
        return False

    for node in nodes:
        if not isinstance(node, dict) or 'id' not in node or 'label' not in node:
            return False

    for edge in edges:
        if not isinstance(edge, dict) or 'from' not in edge or 'to' not in edge:
            return False

    return True


def is_valid_directed_acyclic_graph(task_graph):
    """
    Check if the given task graph is a Directed Acyclic Graph (DAG).

    Args:
        task_graph (dict): A dictionary representing a task graph with 'nodes' and 'edges'. 'nodes' is expected to be a list of dictionaries, each containing 'id' and 'label'. 'edges' is expected to be a list of dictionaries, each containing 'from' and 'to'.

    Returns:
        bool: True if the task graph is a Directed Acyclic Graph (DAG), False otherwise.
    """
    graph = defaultdict(list)
    for edge in task_graph['edges']:
        graph[edge['from']].append(edge['to'])

    visited = set()
    visiting = set()

    def dfs(node):
        if node in visiting:
            return False
        if node in visited:
            return True

        visiting.add(node)
        for neighbor in graph[node]:
            if not dfs(neighbor):
                return False
        visiting.remove(node)
        visited.add(node)
        return True

    for node in task_graph['nodes']:
        if not dfs(node['id']):
            return False

    return True


def is_valid_python_function_output(data):
    """
    Validate if the data is in the correct format for a Python function output.

    Args:
        data (dict): A dictionary containing the Python function output.

    Returns:
        bool: True if the data is in the correct format, False otherwise.
    """
    if isinstance(data, dict) and "python_function" in data and "requirements" in data:
        if isinstance(data["python_function"], str) and isinstance(data["requirements"], list):
            return True
    return False
