import os
import sys
import logging

# Get the directory of the current script
script_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')

# Add the directory to sys.path
sys.path.append(script_dir)

from orchestrator.utils import plot_task_graph, is_valid_directed_acyclic_graph, is_valid_task_graph_response_format


class Orchestrator:
    """
    The Orchestrator class generates task graphs based on user queries using a GPT-4 model.
    """

    def __init__(self, my_gpt_client_manager, timing_profiler=None):
        """
        Initializes the Orchestrator with a GPT-4 client manager and a flag indicating whether user inputs are required.
        """
        self.my_gpt_client_manager = my_gpt_client_manager
        self.timing_profiler = timing_profiler

    def produce_task_graph(self, user_query):
        """
        Produce a task graph for the given user query.

        Args:
            user_query (str): The user query for which to generate a task graph.

        Returns:
            dict: A task graph in JSON format if valid and acyclic, else None.
        """
        if self.timing_profiler:
            self.timing_profiler.start_task_graph_generation_timing()

        logging.info("Producing task graph for user query.")
        prompt = """
            You, as an Orchestrator, are part of a larger LLM-based Agentic Architecture that is responsible for answering a user query in a divide-and-conquer approach. 
            Your task is to decompose a user query into individual tasks and generate a Directed Acyclic Graph (DAG) using the DOT language, represented in JSON format.
        
            Decomposition Strategy:
            1. Evaluate the user query to decide whether to apply **Coarse-Grained Task Decomposition** or **Fine-Grained Task Decomposition**:
                - For Coarse-Grained Task Decomposition, identify a minimal number of large, independent tasks that represent substantial units of work. This should be used when simplifying the execution and minimizing overhead is more beneficial than maximizing parallelism.
                - For Fine-Grained Task Decomposition, break the query down into smaller, granular tasks when the query involves many interdependent tasks that can benefit from parallel execution. The goal here is to maximize parallelism and concurrency where possible.
            2. Choose the appropriate decomposition strategy based on the complexity and parallelizability of the user query. Use coarse-grained decomposition when minimal management is preferred, or switch to fine-grained when high degrees of parallelism are advantageous.
                - Prefer Coarse-Grained Task Decomposition over Fine-Grained Task Decomposition.

            General Requirements:
            1. Ensure there are no cyclic dependencies among tasks, maintaining a clear and executable task flow in the graph.
            2. If task decomposition is unnecessary, represent the entire user query as a single node.
            3. Ensure node uniqueness, so each task is distinct and no redundant or duplicate tasks are produced.
            4. Ensure that each dependent task in the task graph is worded in a way that allows its transitive dependencies to be inferred naturally, including what it expects to receive from its predecessor(s).
            
            User Query: {user_query}

            Response Format:
            - Your response should ONLY include the task graph represented in JSON format.

            Example response format:
            {{
                "task_graph": {{
                    "nodes": [
                        {{"id": "task_A", "label": "Task Description"}},
                        {{"id": "task_B", "label": "Task Description"}},
                        {{"id": "task_C", "label": "Task Description"}},
                        {{"id": "task_D", "label": "Task Description"}}
                    ],
                    "edges": [
                        {{"from": "task_A", "to": "task_B"}},
                        {{"from": "task_B", "to": "task_C"}},
                        {{"from": "task_B", "to": "task_D"}},
                        {{"from": "task_C", "to": "task_D"}}
                    ]
                }}
            }}
            """
        try:
            response = self.my_gpt_client_manager.query_gpt_4o_json(prompt.format(user_query=user_query))
            if is_valid_task_graph_response_format(response):
                if is_valid_directed_acyclic_graph(response["task_graph"]):
                    logging.info("Task graph produced successfully.")
                    return response["task_graph"]
            logging.error("Invalid task graph response format or cyclic dependencies detected.")
        except Exception as e:
            logging.error(f"Error producing task graph: {e}")
        finally:
            if self.timing_profiler:
                self.timing_profiler.stop_task_graph_generation_timing()
        return None
