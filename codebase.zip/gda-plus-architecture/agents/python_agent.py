import os

from gpt.gpt_client import GPT4oAzureClientManager
from helper import is_valid_python_function_output


class PythonAgent:
    """The PythonAgent is responsible for producing python code."""

    def __init__(self):
        """Initialize the PythonAgent with a GPT4oAzureClientManager."""
        self.my_gpt_client = GPT4oAzureClientManager()

    def generate_python_tool(self, task, api_documentation):
        """Generate a Python file containing a self-contained function based on the provided task and API documentation.

        Args:
        - task (str): Description of the task for which the Python function is being generated.
        - api_documentation (str): Detailed documentation of the API or external service to be utilized by the function.

        Returns:
        - tuple: A tuple containing the paths to the generated Python file and its corresponding requirements file.
          - py_file_path (str): Path to the generated Python file (.py).
          - output_dir (str): Directory where the Python file and requirements file are stored.

        Raises:
        - ValueError: If the response format from the GPT-4o model does not match the expected format.

        This method interacts with an AI model to generate a Python function that is self-contained and ready for use.
        The function includes all necessary imports, a comprehensive docstring outlining its purpose, parameters,
        and return values, and any static parameters (such as API keys) required for its operation.

        The generated Python function is saved in a dedicated directory named after the function's name, under the 'tools/'
        directory. Alongside the Python file, a requirements.txt file is created containing all the necessary packages
        specified by the AI model."""

        prompt = """You are an Agent within a larger LLM-based Agentic Architecture tasked with answering a user query using a divide-and-conquer approach.

                    Your specific task is to produce a Python function based on the given Task and API Documentation. 
                    The Python function should be self-contained with all necessary imports included within the function itself. 
                    Additionally, provide a list of all required packages that need to be installed.
                    
                    Guidelines:
                    1. Include all necessary imports inside the function.
                    2. Ensure the Python function is a standalone function definition without nested functions.
                    3. Ensure the Python function is reusable and generalistic, designed to be applicable to similar tasks.
                    4. Include an exhaustive docstring in Google Python Style Guide inside the function, detailing its purpose, parameters, and return values.
                    5. Include all necessary type annotations for parameters and return values.
                    6. List all required packages in a separate requirements file.
                    7. Specify static parameters explicitly: If certain parameters (like API keys) are provided statically or are constants, they should not be included as function parameters but should be used directly within the function.
                    8. Ensure no additional information is included; only produce the Python function and the list of requirements.

                    Task: {task},
                    
                    API Documentation: {api_documentation},
                    
                    Your response must be in JSON format, strictly adhering to the structure below:
                    {{
                        "python_function": "def function_name(parameters: type) -> return_type:\\n    \"\"\"\\n    Description of the function.\\n    \\n    Parameters:\\n    param1 (type): Description of param1.\\n    param2 (type): Description of param2.\\n    \\n    Returns:\\n    return_type: Description of the return value.\\n    \"\"\"\\n    import package_name\\n    from module_name import function_name\\n    # function body",
                        "requirements": ["package_1", "package_2", ...]
                    },},
                    """

        response = self.my_gpt_client.query_gpt_4o_json(input_prompt=prompt.format(task=task,
                                                                                   api_documentation=api_documentation))
        if is_valid_python_function_output(response):

            # Extract function name from python_function
            python_function = response["python_function"]
            function_name = python_function.split('(')[0].split()[-1]

            # Ensure the output directory exists
            output_dir = "tools/" + function_name
            os.makedirs(output_dir, exist_ok=True)

            # Paths for the output files
            py_file_path = os.path.join(output_dir, f'{function_name},.py')
            req_file_path = os.path.join(output_dir, f'{function_name},_requirements.txt')

            # Write the Python function to a .py file
            py_file_content = f"# Auto-generated Python script\n\n{python_function},"
            with open(py_file_path, 'w') as py_file:
                py_file.write(py_file_content)

            # Write the requirements to a requirements.txt file
            with open(req_file_path, 'w') as req_file:
                for requirement in response["requirements"]:
                    req_file.write(requirement + '\n')

            print(
                f"Files created successfully in the '{output_dir},' "
                f"directory: {function_name},.py and {function_name},_requirements.txt")
            return py_file_path, output_dir
        else:
            print(f'Invalid Response format: Response: {response},')
