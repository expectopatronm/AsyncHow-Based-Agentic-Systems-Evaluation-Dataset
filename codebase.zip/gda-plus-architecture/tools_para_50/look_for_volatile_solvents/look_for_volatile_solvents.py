def look_for_volatile_solvents(input_1, input_2):
    """
    Simulates the detection of volatile solvents, which are often found in household products and can be abused as inhalants.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A list of common volatile solvents in a realistic format.
    """
    import json
    volatile_solvents = [
        "Acetone",
        "Benzene",
        "Toluene",
        "Xylene",
        "Hexane",
        "Ethyl acetate"
    ]
    return json.dumps(volatile_solvents)
