def make_creamy_broccoli_soup(input_1, input_2):
    """
    Provides a recipe for making a creamy broccoli soup.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A recipe for creamy broccoli soup.
    """
    return "Creamy Broccoli Soup: Saut� onions and garlic in butter until soft. Add broccoli florets and chicken broth, and simmer until broccoli is tender. Blend until smooth, then stir in cream and season with salt and pepper."
