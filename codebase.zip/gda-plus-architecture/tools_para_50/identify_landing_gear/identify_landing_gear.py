def identify_landing_gear(input_1, input_2):
    """
    Detailed description of what the function does

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "The landing gear of a Boeing 767 consists of a tricycle arrangement with two main landing gear units under the wings and a nose gear unit under the cockpit."
