def recognize_gasses(input_1, input_2):
    """
    Simulates the recognition of gasses that can be inhaled for abuse.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A list of common gasses that are often abused as inhalants in a realistic format.
    """
    import json
    gasses = [
        "Nitrous oxide",
        "Butane",
        "Propane",
        "Freon"
    ]
    return json.dumps(gasses)
