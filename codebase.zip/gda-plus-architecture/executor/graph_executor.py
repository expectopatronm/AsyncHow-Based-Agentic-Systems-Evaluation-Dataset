import os
import sys
import json
import time
import logging
import concurrent.futures
from collections import defaultdict, deque

# Get the directory of the current script
script_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')

# Add the directory to sys.path
sys.path.append(script_dir)

from delegator.utils import (execute_function_locally, post_process_function_response,
                             get_current_datetime, get_current_location)


class GraphExecutor:
    """
    A class that executes tasks based on a task graph, handling dependencies
    and optimizing for parallel execution where possible.
    """

    def __init__(self, my_gpt_client_manager, include_indirect_dependencies=False, timing_profiler=None):
        """
        Initializes the GraphExecutor instance.

        Args:
            include_indirect_dependencies (bool): If True, includes results from all ancestor tasks
                                                  in the inter-task message buffers. If False, only
                                                  direct predecessors are included.
        """
        self.execute_task_func = self._execute_task_func
        self.include_indirect_dependencies = include_indirect_dependencies
        self.execution_results = {}

        self.client = my_gpt_client_manager.openai_client
        self.deployment_name = my_gpt_client_manager.model_name
        self.thread_pool_executor = concurrent.futures.ThreadPoolExecutor()

        self.feedback_system = None
        self.tool_manager = None
        self.task_graph = None
        self.nodes = None
        self.adj_list = None
        self.in_degree = None
        self.reverse_adj_list = None
        self.timing_profiler = timing_profiler

    def initialize_feedback_system(self, feedback_system):
        """Initializes the Feedback System."""
        self.feedback_system = feedback_system

    def initialize_tool_manager(self, tool_manager):
        """Initializes the tool manager for execution."""
        logging.info("Initializing tool manager.")
        self.tool_manager = tool_manager

    def initialize_task_graph(self, task_graph):
        """Initializes the task graph for execution."""
        logging.info("Initializing task graph.")
        self.task_graph = task_graph
        self.nodes, self.adj_list, self.in_degree, self.reverse_adj_list = self._initialize_graph()

    def _initialize_graph(self):
        """
        Initializes the task graph structures including nodes, adjacency lists,
        in-degree counts, and reverse adjacency lists.

        Returns:
            tuple: A tuple containing nodes dictionary, adjacency list, in-degree count, and reverse adjacency list.
        """
        nodes = {node['id']: node for node in self.task_graph['nodes']}
        adj_list = defaultdict(list)
        in_degree = defaultdict(int)
        reverse_adj_list = defaultdict(list)  # To track reverse dependencies

        for edge in self.task_graph['edges']:
            adj_list[edge['from']].append(edge['to'])
            in_degree[edge['to']] += 1
            reverse_adj_list[edge['to']].append(edge['from'])  # Track reverse dependencies

        return nodes, adj_list, in_degree, reverse_adj_list

    def _execute_tool_call(self, function_name, function_args, task_id):
        """
        Executes a tool call by calling the respective function from the ToolManager.

        Args:
            function_name (str): The name of the function/tool to execute.
            function_args (dict): The arguments to pass to the function/tool.
            task_id (str): The task ID for timing profiling.

        Returns:
            str: The response from the tool after execution.
        """

        # Check if the function exists in ToolManager
        function_definition = next((func for func in self.tool_manager.tools
                                    if func['function']['name'] == function_name), None)

        if function_definition:
            try:
                if self.timing_profiler:
                    self.timing_profiler.start_tool_call_timing(task_id, function_name)

                # Call the tool using the new ToolManager's execute_function method
                function_response = self.tool_manager.execute_function(function_name, **function_args)

                # Post-process the response from the tool
                function_response = post_process_function_response(function_response)

                if self.timing_profiler:
                    self.timing_profiler.stop_tool_call_timing(task_id, function_name)

                return function_response
            except Exception as e:
                logging.error(f"Error executing tool {function_name}: {e}")
                return f"Error executing tool {function_name}: {e}"

        return f"Function {function_name} not found."

    def _execute_task_func(self, task, inter_task_buffer):
        """
        Executes a single task based on the provided task description and buffer content.

        Args:
            task (dict): The task node containing id, label, output, and input.
            inter_task_buffer (list): The buffer containing results and outputs from predecessor and ancestor tasks.

        Returns:
            tuple: The final response from the model for the task, the execution timing, and any tool_calls.
        """
        task_id = task['id']
        task_label = task['label']

        logging.info(f"Executing task: {task_label}")

        # Start time measurement for task execution
        if self.timing_profiler:
            self.timing_profiler.start_task_timing(task_id, task_label)
            start_time = self.timing_profiler.execution_times["tasks"][task_id]["task_start_time"]
        else:
            start_time = time.time()

        intra_task_buffer = [{"role": "system", "content": get_current_datetime() + ' ' + get_current_location()}]

        # Separate and order the buffer content
        ancestor_messages = []
        predecessor_messages = []

        for task_info in inter_task_buffer:
            task_type = task_info['task_type']
            task_desc = task_info['task_label']
            task_result = task_info['result']
            tool_calls = task_info.get('tool_calls', [])

            # Append the task result
            if task_type == 'ancestor':
                ancestor_messages += [
                    {"role": "user", "content": f"Ancestral Task Description: {task_desc}"},
                    {"role": "user", "content": f"Ancestral Task Execution Result: {task_result}"}
                ]
                # Append each tool call related to the ancestor
                for tool_call in tool_calls:
                    ancestor_messages += [
                        {"role": "user", "content": f"Ancestral Tool Call Function Name: {tool_call['func_name']}, "
                                                    f"Function Arguments: {json.dumps(tool_call['func_args'])}, "
                                                    f"Function Response: {tool_call['func_response']}"}
                    ]
            elif task_type == 'predecessor':
                predecessor_messages += [
                    {"role": "user", "content": f"Predecessor Task Description: {task_desc}"},
                    {"role": "user", "content": f"Predecessor Task Execution Result: {task_result}"}
                ]
                # Append each tool call related to the predecessor
                for tool_call in tool_calls:
                    predecessor_messages += [
                        {"role": "user", "content": f"Predecessor Tool Call Function Name: {tool_call['func_name']}, "
                                                    f"Function Arguments: {json.dumps(tool_call['func_args'])}, "
                                                    f"Function Response: {tool_call['func_response']}"}
                    ]

        # Append ancestor messages first, followed by predecessor messages
        intra_task_buffer += ancestor_messages + predecessor_messages
        intra_task_buffer += [{"role": "user", "content": f"Task: {task_label}"}]

        if ancestor_messages:
            intra_task_buffer += [{"role": "user",
                                   "content": "Respond ONLY to the Task, given the Task's Ancestral and Predecessoral Descriptions, Execution Results and Tool Call information."
                                              "Your response must be within 50 words."}]
        elif predecessor_messages and not ancestor_messages:
            intra_task_buffer += [{"role": "user",
                                   "content": "Respond ONLY to the Task, given the Task's Predecessoral Descriptions, Execution Results and Tool Call information. "
                                              "Your response must be within 50 words."}]
        else:
            intra_task_buffer += [{"role": "user", "content": "Respond ONLY to the Task. "
                                                              "Your response must be within 50 words."}]

        response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=intra_task_buffer,
            tools=self.tool_manager.tools,
            tool_choice="auto",
        )
        response_message = response.choices[0].message
        intra_task_buffer.append(response_message)

        tool_calls = []
        if response_message.tool_calls:
            futures = []
            for tool_call in response_message.tool_calls:
                function_name = tool_call.function.name
                function_args = json.loads(tool_call.function.arguments)

                future = self.thread_pool_executor.submit(
                    self._execute_tool_call, function_name, function_args, task_id
                )
                futures.append((future, tool_call))

            for future, tool_call in futures:
                try:
                    function_response = future.result()
                    intra_task_buffer.append({
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": tool_call.function.name,
                        "content": function_response,
                    })
                    tool_calls.append({
                        'func_name': tool_call.function.name,
                        'func_args': json.loads(tool_call.function.arguments),
                        'func_response': function_response
                    })  # Store tool name, arguments, and response
                except Exception as e:
                    logging.error(f"Error executing tool {tool_call.function.name}: {e}")

        final_response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=intra_task_buffer,
        )

        # End time measurement
        if self.timing_profiler:
            self.timing_profiler.stop_task_timing(task_id)
            end_time = time.time()  # End time as current time
            duration = self.timing_profiler.execution_times["tasks"][task_id].get("task_time", end_time - start_time)
            execution_timing = {
                "start_time": start_time,
                "end_time": end_time,
                "duration": duration
            }
        else:
            end_time = time.time()
            execution_timing = {
                "start_time": start_time,
                "end_time": end_time,
                "duration": end_time - start_time
            }

        # Store execution result with tool call details
        self.execution_results[task_id] = {
            "result": final_response.choices[0].message.content,
            "execution_timing": execution_timing,
            "tool_calls": tool_calls  # Storing tool information
        }

        return final_response.choices[0].message.content, execution_timing, tool_calls

    def _gather_ancestor_results(self, task_id, visited=None, exclude_predecessors=False):
        """
        Recursively gather results from all ancestor tasks, avoiding duplicates.

        Args:
            task_id (str): The current task ID.
            visited (set): Set of visited nodes to avoid cycles.
            exclude_predecessors (bool): Whether to exclude direct predecessors from the result buffer.

        Returns:
            list: A list of results from ancestor tasks.
        """
        if visited is None:
            visited = set()

        buffer = []
        for ancestor_id in self.reverse_adj_list[task_id]:
            if ancestor_id not in visited:
                visited.add(ancestor_id)
                if ancestor_id in self.execution_results:
                    task_result = self.execution_results[ancestor_id]
                    task_type = 'ancestor' if exclude_predecessors else 'predecessor'

                    # Add task result and tool call info to the buffer
                    buffer.append({
                        'task_type': task_type,
                        'task_id': ancestor_id,
                        'task_label': self.nodes[ancestor_id]['label'],
                        'result': task_result['result'],
                        'tool_calls': task_result.get('tool_calls', [])  # Pass tool call details if available
                    })

                    # Recursively gather from ancestors
                    buffer.extend(self._gather_ancestor_results(ancestor_id, visited, exclude_predecessors=True))
        return buffer

    def _prepare_inter_task_buffer(self, task_id):
        """
        Prepares the inter-task message buffer based on dependencies.

        Args:
            task_id (str): The current task ID.

        Returns:
            list: The inter-task message buffer for the task.
        """
        inter_task_buffer = []

        if self.include_indirect_dependencies:
            inter_task_buffer = self._gather_ancestor_results(task_id)
        else:
            # Only include direct predecessors' results and tool info
            for pred_task_id in self.reverse_adj_list[task_id]:
                if pred_task_id in self.execution_results:
                    task_result = self.execution_results[pred_task_id]
                    inter_task_buffer.append({
                        'task_type': 'predecessor',
                        'task_id': pred_task_id,
                        'task_label': self.nodes[pred_task_id]['label'],
                        'result': task_result['result'],
                        'tool_calls': task_result.get('tool_calls', [])  # Pass tool call details if available
                    })

        return inter_task_buffer

    def _execute_task(self, task_id):
        """
        Executes a single task and stores its result.

        Args:
            task_id (str): The task ID to execute.

        Returns:
            tuple: The result, execution timing, and tool calls from the task execution.
        """

        if self.feedback_system:
            if self.timing_profiler:
                # Start feedback timing before submitting the task
                self.timing_profiler.start_feedback_timing(task_id)

            # Submit the feedback task asynchronously
            feedback_future = self.thread_pool_executor.submit(
                self.feedback_system.add_to_queue, task_id, self.nodes[task_id]['label']
            )

            # Stop feedback timing when the feedback task completes, only if profiling is enabled
            if self.timing_profiler:
                feedback_future.add_done_callback(lambda f: self.timing_profiler.stop_feedback_timing(task_id))

        # Prepare inter-task buffer and execute the task
        inter_task_buffer = self._prepare_inter_task_buffer(task_id)

        # Execute the main task (synchronously)
        result, execution_timing, tool_calls = self.execute_task_func(self.nodes[task_id], inter_task_buffer)

        # Store the execution result for the task
        self.execution_results[task_id] = {
            "result": result,
            "execution_timing": execution_timing,
            "tool_calls": tool_calls
        }

        return result

    def execute_task_graph_parallely(self):
        """
        Executes a task graph where tasks run in parallel where possible,
        and handles dependencies between tasks using inter-task message buffers.

        Returns:
            dict: A dictionary containing the results of each task.
        """
        logging.info("Starting parallel execution of task graph.")
        task_queue = deque([node_id for node_id in self.nodes if self.in_degree[node_id] == 0])

        future_to_task = {}
        while task_queue or future_to_task:
            while task_queue:
                task_id = task_queue.popleft()
                logging.info(f"Submitting task {task_id} for execution.")
                future = self.thread_pool_executor.submit(self._execute_task, task_id)
                future_to_task[future] = task_id

            done, _ = concurrent.futures.wait(future_to_task, return_when=concurrent.futures.FIRST_COMPLETED)

            for future in done:
                task_id = future_to_task.pop(future)
                result = future.result()

                for dependent_task in self.adj_list[task_id]:
                    self.in_degree[dependent_task] -= 1
                    if self.in_degree[dependent_task] == 0:
                        task_queue.append(dependent_task)

        logging.info("Parallel execution of task graph completed.")
        return self.execution_results

    def execute_task_graph_sequentially(self):
        """
        Executes a task graph sequentially, handling dependencies between tasks
        using inter-task message buffers.

        Returns:
            dict: A dictionary containing the results of each task.
        """
        logging.info("Starting sequential execution of task graph.")
        task_queue = deque([node_id for node_id in self.nodes if self.in_degree[node_id] == 0])

        while task_queue:
            task_id = task_queue.popleft()
            logging.info(f"Executing task {task_id}.")
            self._execute_task(task_id)

            for dependent_task in self.adj_list[task_id]:
                self.in_degree[dependent_task] -= 1
                if self.in_degree[dependent_task] == 0:
                    task_queue.append(dependent_task)

        logging.info("Sequential execution of task graph completed.")
        return self.execution_results
