import os
import sys
import json
import time
import logging

# Get the directory of the current script and add the parent directory to sys.path
script_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
sys.path.append(script_dir)

from tools.tool_manager import ToolManager
from gpt.gpt_client import GPT4oAzureClientManager
from delegator.utils import execute_function_locally, post_process_function_response


class Executor:
    """
    Executor class to manage the execution of user queries using GPT-4 on Azure.

    Attributes:
        tools (list): List of tools managed by ToolManager.
        client (object): Instance of GPT4oAzureClientManager for API interaction.
        deployment_name (str): Name of the deployment/model used by the client.
    """

    def __init__(self):
        """
        Initializes the Executor instance.
        """
        my_tools_manager = ToolManager()
        my_gpt_4o_client_manager = GPT4oAzureClientManager()

        self.tools = my_tools_manager.tools
        self.client = my_gpt_4o_client_manager.openai_client
        self.deployment_name = my_gpt_4o_client_manager.model_name

    def execute_query(self, user_query):
        """
        Executes a user query by interacting with the GPT-4 API and processing any tool calls.

        Args:
            user_query (str): The query input by the user.

        Returns:
            tuple: A tuple containing the final response message, execution timing details, and tool calls.
        """
        # Start the timer to measure execution duration
        start_time = time.time()

        # Initialize intra_task_buffer with the system's initial instruction
        intra_task_buffer = [
            {"role": "system", "content": "Your response to the User Query must be within 50 words."}
        ]

        # Add the user's query to the buffer
        intra_task_buffer += [{"role": "user", "content": f"User Query: {user_query}"}]

        # Request a response from the GPT-4 API
        response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=intra_task_buffer,
            tools=self.tools,
            tool_choice="auto",
        )

        response_message = response.choices[0].message
        intra_task_buffer.append(response_message)

        tool_calls = []

        # Process any tool calls specified in the response message
        if response_message.tool_calls:
            for tool_call in response_message.tool_calls:
                function_name = tool_call.function.name
                function_args = json.loads(tool_call.function.arguments)

                function_definition = next((func for func in self.tools
                                            if func['function']['name'] == function_name), None)

                if function_definition:
                    try:
                        folder_path = os.path.join('tools', function_name)

                        # Execute the function locally and process the response
                        function_response = execute_function_locally(
                            folder_path=folder_path,
                            **function_args
                        )
                        function_response = post_process_function_response(function_response)

                        # Append the tool call response to the buffer
                        intra_task_buffer.append({
                            "tool_call_id": tool_call.id,
                            "role": "tool",
                            "name": function_name,
                            "content": function_response,
                        })
                        tool_calls.append({'func_name': function_name,
                                           'func_args': function_args})
                    except Exception as e:
                        logging.error(f"Error executing user query {user_query}: {e}")

        # Request the final response from the GPT-4 API using the updated buffer
        final_response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=intra_task_buffer,
        )

        # End the timer
        end_time = time.time()
        duration = end_time - start_time

        # Log the execution duration
        logging.info(f"User query executed: {user_query} in {duration:.2f} seconds")

        execution_timing = {
            "start_time": start_time,
            "end_time": end_time,
            "duration": duration
        }

        return final_response.choices[0].message.content, execution_timing, tool_calls
