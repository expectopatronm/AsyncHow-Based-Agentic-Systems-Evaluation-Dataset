import sys
import logging
import time

from loguru import logger
from termcolor import colored

from orchestrator.orchestrator import Orchestrator
from delegator.delegator import Delegator
from orchestrator.utils import plot_execution_timings, plot_task_graph
from tools.tool_manager import ToolManager
from feedback.feedback import FeedbackSystem
from gpt.gpt_client import GPT4oAzureClientManager
from executor.graph_executor import GraphExecutor
from utils import TimingProfiler

my_gpt_client_manager = GPT4oAzureClientManager()

filename = "pipeline_error.log"
log_level = "ERROR"
log_format = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS zz}</green> | <level>{level: <8}</level> | <yellow>Line {line: >4} ({file}):</yellow> <b>{message}</b>"
logger.add(sys.stderr, level=log_level, format=log_format, colorize=True, backtrace=True, diagnose=True)
logger.add(filename, level=log_level, format=log_format, colorize=False, backtrace=True, diagnose=True)


logging.basicConfig(level=logging.ERROR)


class Pipeline:
    """Pipeline to process user queries through orchestration and delegation."""

<<<<<<< HEAD
    def __init__(self, always_produce_task_graph=True, semantic_tool_filtering=True, include_indirect_dependencies=False):
        """Initialize the pipeline with orchestrator, tool_manager, delegator, and executor."""
        self.orchestrator = Orchestrator()
        self.tool_manager = ToolManager()
        self.delegator = Delegator()
        self.executor = Executor()
=======
    def __init__(self, semantic_tool_filtering=False, include_indirect_dependencies=False, generate_feedback=False, profile_execution_timings=False):
        """Initialize the pipeline with orchestrator, tool_manager, delegator, feedback_system, and executor."""

        self.timing_profiler = None
        if profile_execution_timings:
            self.timing_profiler = TimingProfiler()

        if self.timing_profiler:
            self.executor = GraphExecutor(my_gpt_client_manager, timing_profiler=self.timing_profiler)
            self.orchestrator = Orchestrator(my_gpt_client_manager, timing_profiler=self.timing_profiler)
            self.delegator = Delegator(my_gpt_client_manager, timing_profiler=self.timing_profiler)
        else:
            self.executor = GraphExecutor(my_gpt_client_manager)
            self.orchestrator = Orchestrator(my_gpt_client_manager)
            self.delegator = Delegator(my_gpt_client_manager)

        self.tool_manager = ToolManager(my_gpt_client_manager)
        self.feedback_system = FeedbackSystem(my_gpt_client_manager)
>>>>>>> master

        self.semantic_tool_filtering = semantic_tool_filtering
        self.include_indirect_dependencies = include_indirect_dependencies
        self.generate_feedback = generate_feedback

        self.task_graph = None
        self.execution_result = None

    def configure_for_query(self, user_query):
        """
        Configure the pipeline based on the query-specific parameters.

        Args:
            user_query (str): The user's query to be processed.
        """
        if self.timing_profiler:
            self.timing_profiler.start_pipeline_timing()

        logging.info("User query needs task breakdown.")

        # Produce task graph
        self.task_graph = self.orchestrator.produce_task_graph(user_query)
        if not self.task_graph:
            raise ValueError("Failed to produce task graph")

        # Initialize Tool Manager with tools and embeddings
        self.tool_manager.initialize_tools_and_embeddings()

        # Filter tools in tool_manager if semantic filtering is enabled
        if self.semantic_tool_filtering:
            task_descriptions = [node['label'] for node in self.task_graph['nodes']]
            self.tool_manager.filter_tools_by_tasks(task_descriptions)

        # Initialize Executor with task_graph and tool_manager and set include_indirect_dependencies
        # Set feedback system to None
        self.executor.initialize_task_graph(self.task_graph)
        self.executor.initialize_tool_manager(self.tool_manager)
        self.executor.include_indirect_dependencies = self.include_indirect_dependencies
        self.executor.feedback_system = None

        # Initialize Executor with Feedback System
        if self.generate_feedback:
            self.feedback_system.clear_cache()
            self.executor.initialize_feedback_system(self.feedback_system)

        # Initialize Delegator with task_graph and executor
        self.delegator.initialize_task_graph(self.task_graph)
        self.delegator.initialize_executor(self.executor)

        # Clear the prior execution result
        self.execution_result = None

    def execute_pipeline(self, user_query, task_graph):
        """
        Execute the pipeline for a given user query.

        Args:
            user_query (str): The user's query to be processed.

        Returns:
            dict: A dictionary containing the user query, task graph, task information, final response,
            and runtime, or None if an error occurs.
        """
        # Start time measurement
        start_time = time.time()

        try:
            # Execute task_graph
            task_results = self.delegator.execute_task_graph()
            if not task_results:
                raise ValueError("Task Graph execution failed")

<<<<<<< HEAD
            task_graph = task_graph

            if needs_breakdown:
                logging.info("User query needs task breakdown.")

                if not task_graph:
                    raise ValueError("Failed to produce task graph")

                # Filter tools in tool_manager
                if self.semantic_tool_filtering:
                    task_descriptions = [node['label'] for node in task_graph['nodes']]
                    self.tool_manager.filter_tools_by_tasks(task_descriptions)

                # Initialize Delegator with tool_manager task graph and executor
                self.delegator.initialize_task_graph(task_graph)
                self.delegator.initialize_tool_manager(self.tool_manager)
                self.delegator.initialize_executor()

                # Set include_indirect_dependencies
                if self.include_indirect_dependencies:
                    self.delegator.executor.include_indirect_dependencies = True

                # Execute task_graph
                task_results = self.delegator.execute_task_graph()
                time.sleep(2)

                if not task_results:
                    raise ValueError("Task Graph execution failed")

                # Process task results
                tasks_info = []
                for task_id, result in task_results.items():
                    # Get the label of the current task
                    label = next(node['label'] for node in task_graph['nodes'] if node['id'] == task_id)

                    # Create task information dictionary
                    task_info = {
                        "id": task_id,
                        "task": label,
                        "result": result['result'],
                        "tool_calls": result['tool_calls'],
                        "execution_timing": result['execution_timing'],
                    }

                    # Hack when no tools are used
                    if len(task_info["tool_calls"]) == 0:
                        task_info["tool_calls"] = ["no_tools_needed"]

                    tasks_info.append(task_info)

                # Obtain final response to user query
                final_response = self.delegator.consolidate_tasks(user_query)
            else:
                # Task does not need a breakdown
                final_response, execution_timing, tool_calls = self.executor.execute_query(user_query)

                tasks_info = {
                    "result": final_response,
                    "tool_calls": tool_calls,
                    "execution_timing": execution_timing
=======
            # Process task results
            tasks_info = []
            for task_id, result in task_results.items():
                # Get the label of the current task
                label = next(node['label'] for node in self.task_graph['nodes'] if node['id'] == task_id)

                # Create task information dictionary
                task_info = {
                    "id": task_id,
                    "task": label,
                    "result": result['result'],
                    "tool_calls": result['tool_calls'],
                    "execution_timing": result['execution_timing'],
>>>>>>> master
                }

                # Hack when no tools are used
                if len(task_info["tool_calls"]) == 0:
                    task_info["tool_calls"] = ["no_tools_needed"]

                tasks_info.append(task_info)

            # Obtain final response to user query
            final_response = self.delegator.consolidate_tasks(user_query)

            # End time measurement
            end_time = time.time()
            runtime = end_time - start_time

            self.execution_result = {
                "user_query": user_query,
                "task_graph": self.task_graph,
                "tasks_info": tasks_info,
                "final_response": final_response,
                "runtime": f"{runtime:.2f} seconds",
            }
            return self.execution_result

        except Exception as e:
            logging.error(f"Pipeline execution failed with error: {e}")
            logger.error(f"Pipeline execution failed with error: {e}")

        finally:
            if self.timing_profiler:
                self.timing_profiler.stop_pipeline_timing()
                self.timing_profiler.save_to_file()
        return None

    def run_with_pretty_print(self, user_query):
        """
        Run the pipeline and print the results in a user-friendly format.

        Args:
            user_query (str): The user's query to be processed.
        """
        logging.info(f"Received user query: {user_query}")
        print(colored(f'\nUser Query: \n{user_query}', 'blue', attrs=["bold"]))

        # Configure pipeline based on the query-specific settings
        self.configure_for_query(user_query)

        # Execute the pipeline
        response = self.execute_pipeline(user_query)
        if response:
            execution_timings = {}

            # Plotting task graph
            plot_task_graph(response["task_graph"])

            # Print each task's information
            for task in response["tasks_info"]:
                print(colored(f'\nTask: {task["task"]}', 'cyan'))
                print(colored(f'Result: {task["result"]}', 'cyan'))
                if task["tool_calls"] != ["no_tools_needed"]:
                    for tool_call in task["tool_calls"]:
                        print(colored(f'Tool Call: {tool_call["func_name"]}', 'light_grey'))
                        print(colored(f'Arguments: {tool_call["func_args"]}', 'light_grey'))

                # Collect execution timings
                execution_timings[task["id"]] = task["execution_timing"]

            # Plot execution timings
            plot_execution_timings(execution_timings)

            # Print the final response and runtime
            print(colored(f'\nFinal Response: \n{response["final_response"]}', 'green', attrs=["bold"]))
            print(colored(f'\nPipeline executed in {response["runtime"]}', 'cyan', attrs=["bold"]))
            print(colored("-------------------------", 'cyan'))
        else:
            print(colored('Pipeline execution failed. Please check the logs for more details.', 'red'))


if __name__ == "__main__":
    # Example queries
    queries = (
        "When does the sun rise today?",
        "What percentage of rain chance will I have in my current area?",
        "How is the weather?",
        "How many hours will the sun shine in my current area today?",
        "What will the weather be like today?",
        "What is the speed limit in the Netherlands?",
        "What is Apple Music?",
        "Can you tell me a joke?",
        "Where is the next Euro 2024 Football match being played? I'd like to book a hotel near the venue.",
        "When was the band Linkin Park formed? And play Numb from them on Spotify.",
        "I would like to set the temperature in my car to two degrees more than the current temperature in Munich. I would also like to know the current weather in Berlin.",
        "Do I need an umbrella today?"
    )

    my_pipeline = Pipeline(semantic_tool_filtering=True, include_indirect_dependencies=True, generate_feedback=True)

    for query in queries:
        my_pipeline.configure_for_query(query)
        my_pipeline.run_with_pretty_print(query)
