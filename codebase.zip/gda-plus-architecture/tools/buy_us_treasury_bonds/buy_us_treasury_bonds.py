def buy_us_treasury_bonds(input_1, input_2):
    """
    Mimics the process of buying U.S. treasury bonds to earn interest bi-annually.

    Args:
        input_1(str): User's personal information required for bond purchase.
        input_2 (bool): Whether the user agrees to the terms and conditions.

    Returns:
        str: Confirmation message with bond details and interest rate.
    """
    import json
    bond_details = {
        'bond_id': 'US123456789',
        'interest_rate': '1.5%',
        'confirmation_message': 'Your U.S. treasury bonds have been successfully purchased.'
    }
    return json.dumps(bond_details)
