def make_chia_pet(input_1, input_2):
    """
    Make a Chia pet out of a 2 liter (0.53 US gal) bottle.

    Args:
        input_1(str): Description of the type of seeds to use.
        input_2 (bool): Whether to use a specific type of soil.

    Returns:
        str: A description of the Chia pet made from the bottle.
    """
    return "Chia pet made from a 2 liter bottle with chia seeds sprouting on the surface."
