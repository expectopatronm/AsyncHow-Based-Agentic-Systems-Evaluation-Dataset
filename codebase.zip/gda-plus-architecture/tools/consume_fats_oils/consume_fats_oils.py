def consume_fats_oils(input_1, input_2):
    """
    Mimics the recommendation to consume between 2 and 3 fats or oils daily.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A string indicating the recommended servings of fats or oils per day.
    """
    return '2 to 3 fats or oils daily'
