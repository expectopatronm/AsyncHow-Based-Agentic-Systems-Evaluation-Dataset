def look_for_frequent_text_messages(input_1, input_2):
    """
    Mimics the tool that looks for frequent text messages.

    Args:
        input_1(str): The phone number to monitor.
        input_2 (bool): Whether to include message content.

    Returns:
        str: A summary of text message frequency.
    """
    import json
    messages = {
        "total_messages": 50,
        "average_per_day": 5,
        "most_active_time": "Evening"
    }
    return json.dumps(messages)