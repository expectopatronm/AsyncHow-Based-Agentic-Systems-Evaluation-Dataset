def examine_buttons(input_1, input_2):
    """
    Detailed description of the what the function does

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Buttons on a genuine Ralph Lauren garment are usually made of high-quality materials and may have 'Ralph Lauren' engraved on them."
