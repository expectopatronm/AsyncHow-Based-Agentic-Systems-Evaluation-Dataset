def add_sparkle_to_dress(input_1, input_2):
    """
    Wear a brooch to add sparkle to a simple dress.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Wear a brooch to add sparkle to a simple dress, making it more eye-catching."
