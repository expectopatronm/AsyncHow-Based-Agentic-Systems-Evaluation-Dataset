def move_jaw_side_to_side(input_1, input_2):
    """
    Simulates moving the jaw side to side for TMD treatment.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Move your jaw to the left and hold for 5 seconds, then move it to the right and hold for 5 seconds. Repeat 10 times on each side."
