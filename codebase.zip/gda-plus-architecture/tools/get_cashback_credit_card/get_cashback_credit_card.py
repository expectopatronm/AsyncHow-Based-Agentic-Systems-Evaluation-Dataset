def get_cashback_credit_card(input_1, input_2):
    """
    Mimics the process of getting a credit card that offers cash-back on purchases.

    Args:
        input_1(str): User's personal information required for credit card application.
        input_2 (bool): Whether the user agrees to the terms and conditions.

    Returns:
        str: Confirmation message with credit card details and cash-back rate.
    """
    import json
    card_details = {
        'card_number': '9876543210',
        'cashback_rate': '2%',
        'confirmation_message': 'Your cash-back credit card has been successfully issued.'
    }
    return json.dumps(card_details)
