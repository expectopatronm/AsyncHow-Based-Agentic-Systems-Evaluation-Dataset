def consume_fruit(input_1, input_2):
    """
    Mimics the recommendation to consume 4 to 5 servings of fruit daily.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A string indicating the recommended servings of fruit per day.
    """
    return '4 to 5 servings of fruit daily'
