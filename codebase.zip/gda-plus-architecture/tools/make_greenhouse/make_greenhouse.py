def make_greenhouse(input_1, input_2):
    """
    Make a greenhouse for a plant.

    Args:
        input_1(str): Description of the type of plant to grow.
        input_2 (bool): Whether to use a specific type of plastic bottle.

    Returns:
        str: A description of the greenhouse made from the bottle.
    """
    return "Greenhouse made from a plastic bottle, suitable for growing small plants."
