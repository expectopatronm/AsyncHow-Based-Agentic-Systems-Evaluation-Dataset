def relieve_vaginal_irritation(input_1, input_2):
    """
    Use Orajel on your vagina to relieve irritation.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Apply a small amount of the cream to the irritated area up to 3 times daily."
