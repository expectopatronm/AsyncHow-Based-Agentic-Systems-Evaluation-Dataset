def practice_reading_skills(input_1, input_2):
    """
    Mimics a tool that advises spending the remaining 20 percent of your time practising your reading skills.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A suggestion on how to practice reading skills.
    """
    return "Spend 20% of your time on reading skills. Read articles, books, or any written material in the target language."
