def bold_red_polish(input_1, input_2):
    """
    Mimics the functionality of going for bright red to look bold.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A description of how bright red nail polish can create a bold look.
    """
    return "Bright red nail polish is a timeless choice for those who want to make a bold statement. It is a powerful colour that exudes confidence and passion."
