def eat_vegetables(input_1, input_2):
    """
    Mimics the recommendation to eat 4 to 5 servings of vegetables every day.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A string indicating the recommended servings of vegetables per day.
    """
    return '4 to 5 servings of vegetables every day'
