def try_sliced_fruit_shish_kabobs(input_1, input_2):
    """
    Generate a recipe for sliced fruit shish-kabobs.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A recipe for sliced fruit shish-kabobs.
    """
    return "Cut various fruits like strawberries, bananas, and grapes into bite-sized pieces. Skewer them onto wooden sticks. Serve chilled."
