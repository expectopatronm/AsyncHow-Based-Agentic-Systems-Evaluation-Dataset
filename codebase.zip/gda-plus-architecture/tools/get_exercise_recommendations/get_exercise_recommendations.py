def get_exercise_recommendations(input_1, input_2):
    """
    Provides a list of exercises to help you get active and healthy.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A JSON string containing a list of exercise recommendations.
    """
    import json
    exercises = [
        {"name": "Running", "duration": "30 minutes", "calories_burned": 300},
        {"name": "Yoga", "duration": "45 minutes", "calories_burned": 180},
        {"name": "Cycling", "duration": "60 minutes", "calories_burned": 500}
    ]
    return json.dumps(exercises)
