def use_reciprocating_saw(input_1, input_2):
    """
    Simulates the use of a reciprocating saw to cut wood.

    Args:
        input_1(str): Description of the wood type or cut pattern.
        input_2 (bool): Whether the cut is rough or precise.

    Returns:
        str: A detailed description of the reciprocating saw cutting process and result.
    """
    return "Using a reciprocating saw, the wood was cut quickly and roughly, suitable for demolition work."
