def find_writing_partner(input_1, input_2):
    """
    Simulates finding a writing partner by generating a list of potential writing partners and their contact information.

    Args:
        input_1(str): The type of writing project (e.g., essay, research paper).
        input_2 (bool): Whether the writing partner should be from the same class or different classes.

    Returns:
        str: A JSON string containing potential writing partners and their contact information.
    """
    import json
    writing_partners = {
        "project_type": "Research Paper",
        "partners": [
            {"name": "David Lee", "email": "david.lee@example.com"},
            {"name": "Eva Green", "email": "eva.green@example.com"},
            {"name": "Frank White", "email": "frank.white@example.com"}
        ]
    }
    return json.dumps(writing_partners)
