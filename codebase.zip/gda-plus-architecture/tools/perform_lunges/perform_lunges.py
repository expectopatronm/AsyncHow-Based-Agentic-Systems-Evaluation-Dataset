def perform_lunges(input_1, input_2):
    """
    Mimics the action of performing lunges and returns a description of the exercise.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Lunges are a great exercise for strengthening the hips, glutes, and thighs. Stand upright, take a step forward with one leg, and lower your hips until both knees are bent at about a 90-degree angle."
