def eat_grains(input_1, input_2):
    """
    Mimics the recommendation to eat 7 to 8 servings of grains each day.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A string indicating the recommended servings of grains per day.
    """
    return '7 to 8 servings of grains each day'
