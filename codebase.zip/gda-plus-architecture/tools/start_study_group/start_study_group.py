def start_study_group(input_1, input_2):
    """
    Simulates the creation of a study group by generating a list of study group members and their contact information.

    Args:
        input_1(str): The subject or topic for the study group.
        input_2 (bool): Whether the study group is online or offline.

    Returns:
        str: A JSON string containing the study group members and their contact information.
    """
    import json
    study_group = {
        "group_name": "Advanced Calculus Study Group",
        "members": [
            {"name": "Alice Johnson", "email": "alice.johnson@example.com"},
            {"name": "Bob Smith", "email": "bob.smith@example.com"},
            {"name": "Charlie Brown", "email": "charlie.brown@example.com"}
        ],
        "meeting_time": "Wednesdays at 5 PM"
    }
    return json.dumps(study_group)
