def set_limits_with_friends_roommates(input_1, input_2):
    """
    Simulates setting limits with friends and roommates by generating a list of agreed-upon rules and boundaries.

    Args:
        input_1(str): The type of limit or boundary to set (e.g., quiet hours, shared chores).
        input_2 (bool): Whether the limit is for friends or roommates.

    Returns:
        str: A JSON string containing the agreed-upon rules and boundaries.
    """
    import json
    limits = {
        "context": "Roommates",
        "rules": [
            {"rule": "Quiet hours from 10 PM to 7 AM"},
            {"rule": "Shared chores schedule: Cleaning on Saturdays"},
            {"rule": "No guests after 9 PM on weekdays"}
        ]
    }
    return json.dumps(limits)
