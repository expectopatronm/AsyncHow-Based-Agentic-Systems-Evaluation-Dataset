def add_chicken_droppings(input_1, input_2):
    """
    Mimics the addition of chicken droppings to the compost.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Confirmation message indicating chicken droppings have been added.
    """
    return 'Chicken droppings have been added to the compost.'
