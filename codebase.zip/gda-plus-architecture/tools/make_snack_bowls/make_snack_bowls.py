def make_snack_bowls(input_1, input_2):
    """
    Turn several 2 liter (0.53 US gal) bottles into snack bowls.

    Args:
        input_1(str): Description of the type of snacks to hold.
        input_2 (bool): Whether to use a specific type of bottle.

    Returns:
        str: A description of the snack bowls made from the bottles.
    """
    return "Snack bowls made from 2 liter bottles, holding chips, nuts, and candies."
