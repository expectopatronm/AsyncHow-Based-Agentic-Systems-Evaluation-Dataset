def bright_colours_energetic(input_1, input_2):
    """
    Mimics the functionality of picking bright colours for an energetic look.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A description of how bright nail polish colours can create an energetic look.
    """
    return "Bright nail polish colours, such as neon pinks, oranges, and yellows, are perfect for conveying an energetic and lively personality. They are great for summer and fun events."
