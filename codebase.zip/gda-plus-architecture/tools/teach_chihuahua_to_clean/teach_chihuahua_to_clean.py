def teach_chihuahua_to_clean(input_1, input_2):
    """
    Simulates teaching a chihuahua to help clean up.

    Args:
        input_1(str): The name of the chihuahua.
        input_2 (bool): Whether the chihuahua successfully picks up an item.

    Returns:
        str: A description of the cleaning training session.
    """
    return "You show your chihuahua how to pick up toys and place them in a basket. After a few tries, your chihuahua successfully picks up a toy and drops it in the basket."
