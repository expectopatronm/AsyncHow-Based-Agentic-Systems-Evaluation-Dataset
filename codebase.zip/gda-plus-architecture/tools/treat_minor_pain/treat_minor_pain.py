def treat_minor_pain(input_1, input_2):
    """
    Treat minor pain on your skin or around your nails.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Apply a small amount of the cream to the affected area 3-4 times daily."
