def roast_broccoli(input_1, input_2):
    """
    Provides a recipe for roasting broccoli in the oven for a crispy texture.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A recipe for crispy roasted broccoli.
    """
    return "Crispy Roasted Broccoli: Toss broccoli florets with olive oil, salt, and pepper, then roast in the oven at 425F for 20-25 minutes until crispy."
