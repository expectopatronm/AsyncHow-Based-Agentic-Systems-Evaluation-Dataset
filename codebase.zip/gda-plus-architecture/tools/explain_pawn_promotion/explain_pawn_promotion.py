def explain_pawn_promotion(input_1, input_2):
    """
    Detailed description of what the function does

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Pawn promotion occurs when a pawn reaches the opposite end of the board and is then converted into any other piece, usually a queen, but it can also be a knight, rook, or bishop."
