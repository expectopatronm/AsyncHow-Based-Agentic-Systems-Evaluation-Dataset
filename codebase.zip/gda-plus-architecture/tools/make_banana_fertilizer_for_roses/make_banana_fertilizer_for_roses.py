def make_banana_fertilizer_for_roses(input_1, input_2):
    """
    Provides instructions on how to make banana fertilizer for roses.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Save banana peels and chop them into small pieces. Bury the pieces around the base of your rose bushes. Banana peels are rich in potassium, which helps roses develop strong stems and vibrant blooms."
