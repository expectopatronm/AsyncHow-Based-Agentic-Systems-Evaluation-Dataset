def apply_tea_tree_oil(input_1, input_2):
    """
    Mimics the application of tea tree oil to blemishes to reduce inflammation.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Tea tree oil applied to blemishes. Inflammation reduced by 30%."
