def cook_broccoli_in_pan(input_1, input_2):
    """
    Provides a quick and easy method for cooking broccoli in a pan.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Instructions for cooking broccoli in a pan.
    """
    return "Pan-Cooked Broccoli: Heat olive oil in a pan over medium heat, add broccoli florets, and cook for 5-7 minutes, stirring occasionally, until tender and slightly browned."
