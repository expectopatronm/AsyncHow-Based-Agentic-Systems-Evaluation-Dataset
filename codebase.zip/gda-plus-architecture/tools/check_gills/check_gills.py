def check_gills(input_1, input_2):
    """
    Detailed description of the what the function does

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Chanterelles have forked gills that are blunt and run down the stem, while Jack o'lanterns have sharp, non-forked gills that do not run down the stem."
