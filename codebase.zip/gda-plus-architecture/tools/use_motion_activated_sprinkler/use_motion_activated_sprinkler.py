def use_motion_activated_sprinkler(input_1, input_2):
    """
    Mimics the action of using a motion-activated sprinkler to discourage skunks.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A message indicating the action has been performed.
    """
    return "A motion-activated sprinkler has been installed to discourage skunks."
