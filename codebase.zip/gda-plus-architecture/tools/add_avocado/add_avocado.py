def add_avocado(input_1, input_2):
    """
    Provides a recipe for avocado hummus.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A recipe for avocado hummus.
    """
    return "Ingredients: 1 can chickpeas, 1 ripe avocado, 1/4 cup tahini, 1/4 cup lemon juice, 2 cloves garlic, 2 tbsp olive oil, salt to taste. Instructions: Blend all ingredients until smooth."
