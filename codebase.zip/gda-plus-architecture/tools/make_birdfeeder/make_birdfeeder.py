def make_birdfeeder(input_1, input_2):
    """
    Turn a plastic bottle into a birdfeeder.

    Args:
        input_1(str): Description of the type of birdseed to use.
        input_2 (bool): Whether to use a specific type of plastic bottle.

    Returns:
        str: A description of the birdfeeder made from the bottle.
    """
    return "Birdfeeder made from a plastic bottle, filled with mixed birdseed."
