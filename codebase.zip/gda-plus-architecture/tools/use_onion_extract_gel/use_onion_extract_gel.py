def use_onion_extract_gel(input_1, input_2):
    """
    Mimics the use of onion extract gel once a day to minimize scars.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Onion extract gel applied. Scar visibility reduced by 20%."
