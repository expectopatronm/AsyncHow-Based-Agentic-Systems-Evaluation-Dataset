import ast
import re


def parse_google_docstring(docstring):
    """
    Parse a Google-style docstring to extract function description, parameters, return information, and raises.

    Args:
        docstring (str): The Google-style docstring to parse.

    Returns:
        tuple: A tuple containing the function description, parameters, required parameters, return information, and raises information.
    """
    lines = docstring.strip().split('\n')
    description_lines = []
    params_section = False
    returns_section = False
    raises_section = False
    params = {}
    required_params = []
    returns = {}
    raises = []
    current_param = None

    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.lower() in ["parameters:", "args:"]:
            params_section = True
            returns_section = False
            raises_section = False
            continue
        elif line.lower() == "returns:":
            returns_section = True
            params_section = False
            raises_section = False
            continue
        elif line.lower() == "raises:":
            raises_section = True
            params_section = False
            returns_section = False
            continue
        if params_section:
            match_named = re.match(r'(\w+)\s*\((\w+)\):\s*(.*)', line)
            match_unnamed = re.match(r'(\w+)\s*:\s*(.*)', line)
            if match_named:
                param_name, param_type, param_desc = match_named.groups()
                params[param_name] = {
                    "type": param_type,
                    "description": param_desc
                }
                required_params.append(param_name)
                current_param = param_name
            elif match_unnamed:
                param_name, param_desc = match_unnamed.groups()
                params[param_name] = {
                    "type": None,
                    "description": param_desc
                }
                required_params.append(param_name)
                current_param = param_name
            elif current_param:  # Handle multi-line descriptions
                params[current_param]['description'] += f" {line}"
        elif returns_section:
            match_named = re.match(r'(\w+)\s*\((\w+)\):\s*(.*)', line)
            match_unnamed = re.match(r'(\w+)\s*:\s*(.*)', line)
            if match_named:
                return_type, return_name, return_desc = match_named.groups()
                returns = {
                    "type": return_type,
                    "name": return_name.strip(),
                    "description": return_desc.strip()
                }
            elif match_unnamed:
                return_type, return_desc = match_unnamed.groups()
                returns = {
                    "type": return_type,
                    "description": return_desc.strip()
                }
            elif returns:  # Handle multi-line descriptions for returns
                returns['description'] += f" {line}"
        elif raises_section:
            match = re.match(r'(\w+)\s*:\s*(.*)', line)
            if match:
                error_type, error_desc = match.groups()
                raises.append({
                    "type": error_type,
                    "description": error_desc.strip()
                })
        else:
            description_lines.append(line)

    description = ' '.join(description_lines)
    return description, params, required_params, returns, raises


def generate_function_metadata(file_content):
    """
    Generate a metadata dictionary from the function definition in the specified file content.

    Args:
        file_content (str): The content of the .py file containing the function.

    Returns:
        dict: A dictionary containing the function metadata.
    """
    tree = ast.parse(file_content)
    function_data = {}

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            func_name = node.name
            docstring = ast.get_docstring(node)
            if docstring:
                description, params, required_params, returns, raises = parse_google_docstring(docstring)

                function_data = {
                    "type": "function",
                    "function": {
                        "name": func_name,
                        "description": description,
                        "parameters": {
                            "type": "object",
                            "properties": params,
                            "required": required_params
                        },
                        "returns": returns if returns else None,
                        "raises": raises if raises else None
                    }
                }
                break

    return function_data


def replace_str_with_string(d):
    """
    Replace 'str' with 'string' in a dictionary.

    Args:
        d (dict): Dictionary to process.

    Returns:
        dict: Processed dictionary with 'str' replaced by 'string'.
    """
    for key, value in d.items():
        if isinstance(value, dict):
            d[key] = replace_str_with_string(value)
        elif isinstance(value, str) and value == "str":
            d[key] = "string"
    return d


def replace_bool_with_boolean(d):
    """
    Replace 'bool' with 'boolean' in a dictionary.

    Args:
        d (dict): Dictionary to process.

    Returns:
        dict: Processed dictionary with 'bool' replaced by 'boolean'.
    """
    if isinstance(d, dict):
        for key, value in d.items():
            if isinstance(value, dict):
                d[key] = replace_bool_with_boolean(value)
            elif isinstance(value, str) and value == "bool":
                d[key] = "boolean"
    elif isinstance(d, list):
        for index, item in enumerate(d):
            d[index] = replace_bool_with_boolean(item)
    return d
