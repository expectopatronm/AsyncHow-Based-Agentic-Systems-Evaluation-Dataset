def focus_on_oral_exam(input_1, input_2):
    """
    Mimics a tool that advises spending 30 percent of your time focusing on your oral examination.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A suggestion on how to focus on oral examination.
    """
    return "Spend 30% of your time on oral examination. Practice speaking in front of a mirror or with a friend."
