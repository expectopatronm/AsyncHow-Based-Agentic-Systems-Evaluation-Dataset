def practice_listening_skills(input_1, input_2):
    """
    Mimics a tool that advises spending 20 percent of your time practising your listening skills.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A suggestion on how to practice listening skills.
    """
    return "Spend 20% of your time on listening skills. Listen to podcasts, audiobooks, or watch videos in the target language."
