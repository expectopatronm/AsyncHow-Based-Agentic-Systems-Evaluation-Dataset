def refer_to_nouns_with_demonstrative_pronouns(input_1, input_2):
    """
    Generate sentences referring to nouns with demonstrative pronouns.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A JSON string containing sentences with demonstrative pronouns.
    """
    import json
    sentences = [
        "This is my book.",
        "That is your car.",
        "These are our friends.",
        "Those are their houses."
    ]
    return json.dumps(sentences)
