def tug_o_war_with_chihuahua(input_1, input_2):
    """
    Simulates having a tug-o-war game with a chihuahua.

    Args:
        input_1(str): The name of the chihuahua.
        input_2 (bool): Whether the chihuahua wins the tug-o-war.

    Returns:
        str: A description of the tug-o-war game.
    """
    return "You grab one end of a rope toy and your chihuahua grabs the other end. After a playful struggle, your chihuahua pulls the rope out of your hand and runs around triumphantly."
