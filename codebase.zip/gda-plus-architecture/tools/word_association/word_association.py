def word_association(input_1, input_2):
    """
    Generate a list of words associated with a given word to help with idea generation.

    Args:
        input_1(str): The word to associate with.
        input_2 (bool): A flag to determine if the associations should be broad or narrow.

    Returns:
        str: A JSON string containing a list of associated words.
    """
    import json
    associations = ["creativity", "imagination", "thought", "concept", "notion"]
    return json.dumps(associations)
