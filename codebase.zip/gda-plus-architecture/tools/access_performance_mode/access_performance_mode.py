def access_performance_mode(input_1, input_2):
    """
    Detailed description of the what the function does

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return 'Performance Mode: Go to career and press triangle, triangle, x, triangle, triangle, square twice.'
