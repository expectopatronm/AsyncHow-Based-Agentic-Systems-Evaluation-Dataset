def writing_prompts(input_1, input_2):
    """
    Provide writing prompts to get started.

    Args:
        input_1(str): The genre or theme of the writing prompt.
        input_2 (bool): A flag to determine if the prompt should be detailed or vague.

    Returns:
        str: A string containing a writing prompt.
    """
    prompt = "Write about a time when you felt completely out of your comfort zone."
    return prompt
