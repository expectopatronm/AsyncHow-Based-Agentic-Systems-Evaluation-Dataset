def add_broccoli_to_pasta(input_1, input_2):
    """
    Provides a recipe suggestion for adding broccoli to pasta for more texture and taste.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A pasta recipe that includes broccoli.
    """
    return "Broccoli Pasta: Cook pasta according to package instructions. In the last 3 minutes of cooking, add broccoli florets to the boiling water. Drain and toss with olive oil, garlic, and Parmesan cheese."
