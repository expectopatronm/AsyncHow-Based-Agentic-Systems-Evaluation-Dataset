def listen_to_music(input_1, input_2):
    """
    Suggest a playlist to help think of new ideas.

    Args:
        input_1(str): The genre of music preferred.
        input_2 (bool): A flag to determine if the playlist should be instrumental or with lyrics.

    Returns:
        str: A JSON string containing a list of song titles and artists.
    """
    import json
    playlist = [
        {"title": "Clair de Lune", "artist": "Claude Debussy"}
    ]
    return json.dumps(playlist)
