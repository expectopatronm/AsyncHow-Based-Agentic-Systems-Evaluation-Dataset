def make_mosaic_artwork(input_1, input_2):
    """
    Use the bottle caps to make a mosaic artwork.

    Args:
        input_1(str): Description of the type of design to create.
        input_2 (bool): Whether to use a specific type of bottle caps.

    Returns:
        str: A description of the mosaic artwork made from the bottle caps.
    """
    return "Mosaic artwork made from colorful bottle caps, forming a floral design."
