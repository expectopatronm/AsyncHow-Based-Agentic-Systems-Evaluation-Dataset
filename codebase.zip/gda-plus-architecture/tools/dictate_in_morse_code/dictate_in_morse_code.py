def dictate_in_morse_code(input_1, input_2):
    """
    Converts a given string into Morse Code.

    Args:
        input_1 (str): The input string to be converted to Morse Code.
        input_2 (bool): A flag indicating whether to use a specific Morse Code standard.

    Returns:
        str: The input string converted into Morse Code.
    """
    morse_code_dict = {
        'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.', 'g': '--.', 'h': '....',
        'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 'p': '.--.',
        'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-',
        'y': '-.--', 'z': '--..', '1': '.----', '2': '..---', '3': '...--', '4': '....-', '5': '.....',
        '6': '-....', '7': '--...', '8': '---..', '9': '----.', '0': '-----', ' ': '/'
    }
    return ' '.join(morse_code_dict.get(char, char) for char in input_1.lower())