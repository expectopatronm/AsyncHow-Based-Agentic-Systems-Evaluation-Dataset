def note_social_media_interactions(input_1, input_2):
    """
    Mimics the tool that notes social media interactions.

    Args:
        input_1(str): The social media platform to monitor.
        input_2 (bool): Whether to include likes and comments.

    Returns:
        str: A summary of social media interactions.
    """
    import json
    interactions = {
        "likes": 15,
        "comments": 5,
        "shares": 2,
        "mentions": 3
    }
    return json.dumps(interactions)