def chihuahua_play_fetch(input_1, input_2):
    """
    Simulates getting a chihuahua to play fetch.

    Args:
        input_1(str): The name of the chihuahua.
        input_2 (bool): Whether the chihuahua retrieves the thrown item.

    Returns:
        str: A description of the fetch game.
    """
    return "You throw a small ball across the yard. Your chihuahua runs after it, picks it up, and brings it back to you, wagging its tail."
