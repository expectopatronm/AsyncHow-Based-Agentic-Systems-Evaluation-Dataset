def stick_brooch_to_skirt(input_1, input_2):
    """
    Stick your brooch to the waist of a skirt for an unexpected touch.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Stick your brooch to the waist of a skirt for an unexpected and chic touch."
