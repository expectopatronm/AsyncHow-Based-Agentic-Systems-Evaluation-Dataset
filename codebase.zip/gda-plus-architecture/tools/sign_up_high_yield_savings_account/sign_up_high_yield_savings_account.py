def sign_up_high_yield_savings_account(input_1, input_2):
    """
    Mimics the process of signing up for a high yield online savings account to earn 1% interest.

    Args:
        input_1(str): User's personal information required for account sign-up.
        input_2 (bool): Whether the user agrees to the terms and conditions.

    Returns:
        str: Confirmation message with account details and interest rate.
    """
    import json
    account_details = {
        'account_number': '1234567890',
        'interest_rate': '1%',
        'confirmation_message': 'Your high yield savings account has been successfully created.'
    }
    return json.dumps(account_details)
