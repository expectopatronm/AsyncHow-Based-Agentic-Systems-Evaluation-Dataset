def pay_attention_to_communication_at_night(input_1, input_2):
    """
    Mimics the tool that pays attention to communication at night.

    Args:
        input_1(str): The time range to monitor.
        input_2 (bool): Whether to include call logs.

    Returns:
        str: A summary of night-time communication.
    """
    import json
    night_communication = {
        "total_night_messages": 20,
        "total_night_calls": 3,
        "most_active_hour": "10 PM"
    }
    return json.dumps(night_communication)