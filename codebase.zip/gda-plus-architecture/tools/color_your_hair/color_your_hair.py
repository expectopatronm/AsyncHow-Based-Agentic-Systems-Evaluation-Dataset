def color_your_hair(input_1, input_2):
    """
    Provides tips on coloring your hair to maintain a youthful appearance.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Choose a hair color that complements your skin tone. Consider highlights or lowlights to add dimension and avoid very dark or very light shades."
