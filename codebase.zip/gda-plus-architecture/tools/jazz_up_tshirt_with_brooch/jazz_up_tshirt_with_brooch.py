def jazz_up_tshirt_with_brooch(input_1, input_2):
    """
    Jazz up a simple T-shirt with a brooch.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Jazz up a simple T-shirt with a brooch, adding a fun and stylish element."
