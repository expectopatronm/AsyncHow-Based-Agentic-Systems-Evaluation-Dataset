def make_roasted_garlic_parmesan_hummus(input_1, input_2):
    """
    Provides a recipe for roasted garlic parmesan hummus.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A recipe for roasted garlic parmesan hummus.
    """
    return "Ingredients: 1 can chickpeas, 1 head roasted garlic, 1/4 cup tahini, 1/4 cup lemon juice, 1/4 cup grated parmesan, 2 tbsp olive oil, salt to taste. Instructions: Blend all ingredients until smooth."
