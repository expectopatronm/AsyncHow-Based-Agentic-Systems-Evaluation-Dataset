def include_dairy(input_1, input_2):
    """
    Mimics the recommendation to include 2 to 3 servings of low fat or nonfat dairy products in your daily diet.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A string indicating the recommended servings of dairy products per day.
    """
    return '2 to 3 servings of low fat or nonfat dairy products each day'
