def pin_brooch_to_blouse(input_1, input_2):
    """
    Pin your brooch to the breast of a blouse for a classic look.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Pin your brooch to the breast of a blouse for a classic and elegant look."
