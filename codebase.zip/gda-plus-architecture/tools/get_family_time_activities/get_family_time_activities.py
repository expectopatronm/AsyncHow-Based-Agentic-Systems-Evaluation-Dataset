def get_family_time_activities(input_1, input_2):
    """
    Provides a list of activities to spend time with family and friends.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A JSON string containing a list of family time activities.
    """
    import json
    activities = [
        {"activity": "Board Games", "duration": "2 hours"},
        {"activity": "Picnic", "duration": "3 hours"},
        {"activity": "Movie Night", "duration": "2.5 hours"}
    ]
    return json.dumps(activities)
