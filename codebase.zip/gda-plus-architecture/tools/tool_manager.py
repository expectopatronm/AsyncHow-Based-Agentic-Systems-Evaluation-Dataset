import os
import sys
import types
import json
import logging
import importlib.util
from concurrent.futures import ThreadPoolExecutor, as_completed
from loguru import logger

import faiss
import numpy as np
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    pipeline,
)

# Get the directory of the current script
script_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')

# Add the directory to sys.path
sys.path.append(script_dir)

from tools.utils import generate_function_metadata, replace_str_with_string, replace_bool_with_boolean
from gpt.gpt_client import GPT4oAzureClientManager


class ToolManager:
    def __init__(self, my_gpt_client_manager, json_path='tools.json', embeddings_json_path='tool_embeddings.json'):
        """
        Initialize the ToolManager with the path to the JSON file and the embeddings JSON file.

        Args:
            json_path (str): Path to the JSON file. Default is 'tools.json'.
            embeddings_json_path (str): Path to the JSON file for storing embeddings. Default is 'tool_embeddings.json'.
        """
        self.json_path = os.path.join(script_dir, 'tools', json_path)
        self.embeddings_json_path = os.path.join(script_dir, 'tools', embeddings_json_path)

        self.my_gpt_client_manager = my_gpt_client_manager
        self.tools = None
        self.embeddings = None

        # Load Classifier
        classifier_path = os.path.join(script_dir, "fine_tuned_models", "cariad-bert-NLU/checkpoint-6150")
        classifier_model = AutoModelForSequenceClassification.from_pretrained(classifier_path)
        classifier_tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
        self.classifier_pipeline = pipeline(task='text-classification', model=classifier_model, tokenizer=classifier_tokenizer)

        # Initialize tools and embeddings
        self.initialize_tools_and_embeddings()

        # Load and attach methods dynamically from python_tools folder
        self.load_and_attach_methods()

    def _read_tools_json(self):
        """Read tools from the JSON file, ensuring an empty list is returned if the file is missing or empty."""
        if not os.path.exists(self.json_path):
            # Create an empty file if it doesn't exist
            self.tools = []
            self.write_tools_json()  # Write the empty list to the file
            return []

        try:
            with open(self.json_path, 'r') as file:
                data = file.read().strip()
                return json.loads(data) if data else []  # Return an empty list if file is empty
        except (FileNotFoundError, json.JSONDecodeError):
            return []  # Ensure it always returns an empty list in case of an error

    def _read_embeddings_json(self):
        """Read embeddings from the embeddings JSON file, ensuring an empty dictionary is returned if the file is missing or empty."""
        if not os.path.exists(self.embeddings_json_path):
            # Create an empty file if it doesn't exist
            self.embeddings = {}
            self.write_embeddings_json()  # Write the empty dictionary to the file
            return {}

        try:
            with open(self.embeddings_json_path, 'r') as file:
                data = file.read().strip()
                return json.loads(data) if data else {}  # Return an empty dictionary if file is empty
        except (FileNotFoundError, json.JSONDecodeError):
            return {}  # Ensure it always returns an empty dictionary in case of an error

    def write_tools_json(self):
        """Write tools to the JSON file, ensuring an empty list is written if tools is None."""
        with open(self.json_path, 'w') as file:
            json.dump(self.tools or [], file, indent=4)  # Ensure an empty list is written if tools is None

    def write_embeddings_json(self):
        """Write embeddings to the JSON file, ensuring an empty dictionary is written if embeddings is None."""
        with open(self.embeddings_json_path, 'w') as file:
            json.dump(self.embeddings or {}, file,
                      indent=4)  # Ensure an empty dictionary is written if embeddings is None

    def initialize_tools_and_embeddings(self):
        """Initialize tools and embeddings."""
        self.tools = self._read_tools_json()
        self.embeddings = self._read_embeddings_json()

    @staticmethod
    def tool_exists(existing_tool, new_tool):
        """Check if a tool already exists in the tool list."""
        if existing_tool['function']['name'] != new_tool['function']['name']:
            return False
        if existing_tool['function']['description'] != new_tool['function']['description']:
            return False
        return existing_tool['function']['parameters'] == new_tool['function']['parameters']

    def parse_tool_from_function_docstring(self, file_path):
        """Parse a tool definition from a function's docstring and add it to the tool list."""
        logging.info(f"Parsing file: {file_path}")
        logger.debug(f"Parsing file: {file_path}")
        with open(file_path, 'r', encoding='utf-8') as file:
            file_content = file.read()

        tool = None
        try:
            tool = generate_function_metadata(file_content)
        except Exception as e:
            logging.error("Can load tool", file_content)

        if not tool:
            logging.info(f"No valid function found in {file_path}")
            return

        logging.info(f"Parsed tool: {tool}")

        # Minor post process tool to fit to OpenAPI standards
        tool = replace_str_with_string(tool)
        tool = replace_bool_with_boolean(tool)

        # Check if the tool already exists and add if it does not
        with ThreadPoolExecutor() as executor:
            futures = [executor.submit(self.tool_exists, existing_tool, tool) for existing_tool in self.tools]
            for future in as_completed(futures):
                if future.result():
                    logging.info("Tool already exists.")
                    return tool

        # Add the new tool to the list
        self.tools.append(tool)
        self.write_tools_json()

        # Generate and store embedding for the tool description
        embedding = self.my_gpt_client_manager.generate_embedding(tool['function']['description'])
        self.embeddings[tool['function']['name']] = embedding
        self.write_embeddings_json()

        logging.info("Tool and its embedding added.")
        return tool

    def parse_all_function_files(self, function_files_path="python_tools"):
        """Parses all function files in the function_files_path directory by calling parse_tool_from_function_docstring."""
        current_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), function_files_path)
        for item in os.listdir(current_dir):
            item_path = os.path.join(current_dir, item)

            # Skip directories like __pycache__
            if os.path.isdir(item_path) and item != '__pycache__':
                python_file_path = os.path.join(item_path, f"{item}.py")
                if os.path.exists(python_file_path):
                    self.parse_tool_from_function_docstring(python_file_path)
                else:
                    logging.info(f"No matching Python file for {item} folder.")
            elif os.path.isfile(item_path) and item.endswith(".py") and item != '__init__.py':
                self.parse_tool_from_function_docstring(item_path)

    def filter_tools_by_tasks(self, tasks, threshold=0.25):
        """
        Filter tools based on a list of tasks using semantic search with FAISS.

        Args:
            tasks (list): List of task descriptions to filter tools.
            threshold (float): The cosine similarity threshold to consider a match. Default is 0.25.

        Returns:
            None: Updates the self.tools with the filtered list of tools.
        """

        # Convert embeddings dictionary to a NumPy array
        tool_names = list(self.embeddings.keys())
        tool_embeddings = np.array(list(self.embeddings.values()), dtype=np.float32)

        # Build FAISS index
        dimension = tool_embeddings.shape[1]
        index = faiss.IndexFlatIP(dimension)  # Using Inner Product for cosine similarity
        faiss.normalize_L2(tool_embeddings)  # Normalize embeddings to use cosine similarity
        index.add(tool_embeddings)

        filtered_tools = set()

        # Using ThreadPoolExecutor to handle embedding generation concurrently
        with ThreadPoolExecutor() as executor:
            futures = [executor.submit(self.my_gpt_client_manager.generate_embedding, task) for task in tasks]
            for future in as_completed(futures):
                task_embedding = np.array(future.result(), dtype=np.float32)  # Convert list to NumPy array
                faiss.normalize_L2(task_embedding.reshape(1, -1))  # Normalize task embedding
                distances, indices = index.search(task_embedding.reshape(1, -1), len(tool_embeddings))

                # Filter tools based on the similarity threshold
                best_tools = [
                    tool_names[i] for i, dist in zip(indices[0], distances[0])
                    if dist >= threshold
                ]
                filtered_tools.update(best_tools)

        # Update self.tools with the filtered list of tools
        if filtered_tools:
            self.tools = [tool for tool in self.tools if tool['function']['name'] in filtered_tools]

    def load_and_attach_methods(self):
        """Dynamically load all .py files from python_tools folder and attach them as methods."""
        python_tools_dir = os.path.join(script_dir, 'tools', 'python_tools')

        for item in os.listdir(python_tools_dir):
            item_path = os.path.join(python_tools_dir, item)
            if item.endswith(".py"):
                function_name = os.path.splitext(item)[0]  # Get the filename without extension

                # Dynamically load the module from the .py file
                spec = importlib.util.spec_from_file_location(function_name, item_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)

                # Get the function from the loaded module
                func = getattr(module, function_name, None)

                if func and callable(func):
                    # Bind the function to the ToolManager instance using MethodType
                    bound_method = types.MethodType(func, self)
                    setattr(self, function_name, bound_method)

                    logging.info(f"Attached method: {function_name} from {item_path}")
                else:
                    logging.warning(f"No callable function named '{function_name}' found in {item_path}")

    def execute_function(self, function_name, *args, **kwargs):
        """
        Execute a function by dynamically invoking a method loaded from the python_tools folder.

        Args:
            function_name (str): The name of the function to execute.
            *args: Arguments to pass to the function.
            **kwargs: Keyword arguments to pass to the function.

        Returns:
            The result of the function execution, or None if the function or file does not exist.
        """
        method = getattr(self, function_name, None)
        if not callable(method):
            logging.error(f"Function {function_name} not found or not callable.")
            return None

        logging.info(f"Executing {function_name} with args: {args} and kwargs: {kwargs}")
        return method(*args, **kwargs)


if __name__ == "__main__":
    my_gpt_client_manager = GPT4oAzureClientManager()

    # Initialize the ToolManager
    my_tool_manager = ToolManager(my_gpt_client_manager=my_gpt_client_manager)
    my_tool_manager.parse_all_function_files()

    # Example: Dynamically execute a function (now a method) from python_tools
    result = my_tool_manager.execute_function("execute_car_function", "Lower the window.")
    print(f"Result: {result}")
