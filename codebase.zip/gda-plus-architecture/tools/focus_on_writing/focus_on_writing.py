def focus_on_writing(input_1, input_2):
    """
    Mimics a tool that advises spending 30 percent of your time focusing on your writing piece and taking in as much vocabulary as you can.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A suggestion on how to focus on writing and vocabulary.
    """
    return "Spend 30% of your time on writing. Use tools like thesaurus and vocabulary apps to enhance your word bank."
