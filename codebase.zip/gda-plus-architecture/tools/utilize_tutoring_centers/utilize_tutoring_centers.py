def utilize_tutoring_centers(input_1, input_2):
    """
    Provides information about available tutoring centers and their schedules.

    Args:
        input_1(str): The subject for which tutoring information is needed.
        input_2 (bool): Whether online tutoring options are preferred.

    Returns:
        str: A JSON string containing details about tutoring centers, including names, locations, and schedules.
    """
    import json
    data = {
        "centers": [
            {"name": "Biology Tutoring Center", "location": "Building A, Room 101", "schedule": "Mon-Fri 9am-5pm"},
            {"name": "Science Learning Hub", "location": "Building B, Room 202", "schedule": "Mon-Fri 10am-6pm"}
        ]
    }
    return json.dumps(data)
