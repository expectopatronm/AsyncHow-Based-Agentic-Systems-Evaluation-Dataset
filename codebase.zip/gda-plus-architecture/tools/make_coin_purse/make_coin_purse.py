def make_coin_purse(input_1, input_2):
    """
    Turn two plastic bottles into a zippered coin purse.

    Args:
        input_1(str): Description of the type of zipper to use.
        input_2 (bool): Whether to use a specific type of plastic bottle.

    Returns:
        str: A description of the zippered coin purse made from the bottles.
    """
    return "Zippered coin purse made from two plastic bottles, with a colorful zipper."
