def eat_healthy_fats(input_1, input_2):
    """
    Mimics the action of eating healthy fats by returning a list of healthy fat sources.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A JSON string containing a list of healthy fat sources.
    """
    import json
    healthy_fats = [
        "Avocados",
        "Olive oil",
        "Nuts and seeds",
        "Fatty fish like salmon",
        "Chia seeds"
    ]
    return json.dumps(healthy_fats)
