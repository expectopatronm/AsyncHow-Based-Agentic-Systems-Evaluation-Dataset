def define_nouns_with_relative_pronouns(input_1, input_2):
    """
    Generate sentences defining nouns with relative pronouns.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A JSON string containing sentences with relative pronouns.
    """
    import json
    sentences = [
        "The person who called you is my friend.",
        "The book that you gave me is interesting.",
        "The place where we met is beautiful.",
        "The reason why I came is to see you."
    ]
    return json.dumps(sentences)
