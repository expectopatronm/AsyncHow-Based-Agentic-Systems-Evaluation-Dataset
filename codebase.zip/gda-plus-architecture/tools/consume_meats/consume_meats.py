def consume_meats(input_1, input_2):
    """
    Mimics the recommendation to consume 6 or fewer servings of lean meats, fish, and poultry each day.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A string indicating the recommended servings of lean meats, fish, and poultry per day.
    """
    return '6 or fewer servings of lean meats, fish, and poultry each day'
