def find_nearest_speed_camera(self, route):
    """
    Finds the nearest speed camera on the specified route.

    Args:
        route (str): The route on which to find the nearest speed camera.

    Returns:
        str: Confirmation message indicating the nearest speed camera was found successfully.
    """
    return f'Nearest speed camera on route {route} found successfully.'