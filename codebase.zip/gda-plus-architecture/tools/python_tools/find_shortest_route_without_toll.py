def find_shortest_route_without_toll(self, destination):
    """
    Finds the shortest route to the specified destination without tolls.

    Args:
        destination (str): The destination for which the route is to be calculated.

    Returns:
        str: Confirmation message indicating the shortest route without tolls was found successfully.
    """
    return f'Shortest route to {destination} without tolls found successfully.'