def purchase_feature(self, feature_name):
    """
    Provides information on how to purchase a specified feature.

    Args:
        feature_name (str): The name of the feature to purchase (e.g., 'High Beam Assistant', 'Audi pre sense').

    Returns:
        str: Confirmation message indicating the feature has been purchased successfully.
    """
    return f'{feature_name} purchased successfully.'