def get_nearest_store(self, store_name, location):
    """
    Returns the location of the nearest specified store based on the user's location.

    This function determines the closest specified store (e.g., Lidl, Aldi, McDonald's, Burger King, EnBW charging station) based on the user's current location.

    Args:
        store_name (str): The name of the store to find (e.g., 'EnBW charging station', 'Lidl', 'Aldi', 'McDonald's', 'Burger King').
        location (str): The location of the user.

    Returns:
        str: The location of the nearest specified store.
    """
    return f"{store_name} is 5 minutes from {location}."