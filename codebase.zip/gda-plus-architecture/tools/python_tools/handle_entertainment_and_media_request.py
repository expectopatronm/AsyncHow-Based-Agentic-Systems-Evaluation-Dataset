def handle_entertainment_and_media_request(self, service, action, content):
    """
    Provides entertainment content such as music, audiobooks, and videos based on user requests and subscriptions.
    Executes actions such as play, stop, pause, and resume on the specified content.

    Args:
        service (str): The entertainment service (e.g., Spotify, Netflix).
        action (str): The action to perform (e.g., play, stop, pause, resume).
        content (str): The specific content to interact with (e.g., song name, audiobook title).

    Returns:
        dict: A response simulating the API behavior with the following keys:
            - service (str): The entertainment service.
            - action (str): The action performed.
            - content (str): The specific content interacted with.
            - status (str): The result of the action, indicating success or failure with details.
    """
    services = {
        'spotify': ['play', 'stop', 'pause', 'resume'],
        'amazon music': ['play', 'stop', 'pause', 'resume'],
        'netflix': ['play', 'stop', 'pause', 'resume'],
        'audible': ['play', 'stop', 'pause', 'resume']
    }

    service = service.lower()
    action = action.lower()
    content = content.lower()

    if service not in services:
        return {
            "service": service,
            "action": action,
            "content": content,
            "status": "failure - unknown service"
        }

    if action not in services[service]:
        return {
            "service": service,
            "action": action,
            "content": content,
            "status": "failure - unknown action"
        }

    # Action results
    status_messages = {
        'play': 'playing',
        'stop': 'stopped',
        'pause': 'paused',
        'resume': 'resumed'
    }

    response = {
        "service": service,
        "action": action,
        "content": content,
        "status": f"success - {status_messages[action]} '{content}' on {service}"
    }

    return response
