def get_weather_tomorrow(self, destination):
    """
    Returns the weather forecast for tomorrow at the specified destination.

    This function provides the weather forecast for the next day at a given destination.

    Args:
        destination (str): The destination for which the weather forecast is requested.

    Returns:
        str: The weather forecast for tomorrow at the specified destination.
    """
    return f'Sunny with a high of 25°C at {destination}'