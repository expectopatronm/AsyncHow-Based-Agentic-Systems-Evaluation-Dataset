def find_nearest_workshop(self, location, authorized=False):
    """
    Finds the nearest workshop or authorized workshop at the specified location.

    Args:
        location (str): The location to find the workshop.
        authorized (bool): Whether to find an authorized workshop. Default is False.

    Returns:
        str: Confirmation message indicating the nearest workshop was found successfully.
    """
    if authorized:
        return f'Nearest authorized workshop at {location} found successfully.'
    else:
        return f'Nearest workshop at {location} found successfully.'