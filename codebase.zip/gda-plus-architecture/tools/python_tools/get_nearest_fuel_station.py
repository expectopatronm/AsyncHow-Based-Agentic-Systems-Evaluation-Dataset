def get_nearest_fuel_station(self, location):
    """
    Fetches fuel stations near the specified location.

    Args:
        location (str): The location for which to search fuel stations.
                        Should be in the format "City,Street+Address" or similar.

    Returns:
        dict: A JSON response containing information about fuel stations near the given location.
    """

    import requests

    url = f"https://agreeable-water-09f0b7103.5.azurestaticapps.net/fuel?location={location}"
    response = requests.get(url)
    return response.json()