def get_energy_cost_at_station(self, station_name, location):
    """
    Returns the price per kilowatt hour at the specified gas station.

    This function determines the cost of electric charging per kilowatt hour at the specified gas station.

    Args:
        station_name (str): The name of the gas station to check (e.g., 'work gas station').
        location (str): The location of the gas station to check.

    Returns:
        str: The cost per kilowatt hour in cents.
    """
    return "35"