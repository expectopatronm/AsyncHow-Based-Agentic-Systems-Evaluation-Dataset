def inquire_function_activation(self, feature_name):
    """
    Provides information on how to activate a booked feature.

    Args:
        feature_name (str): The name of the feature to activate (e.g., 'seat heating', 'traffic sign recognition').

    Returns:
        str: Confirmation message indicating the feature has been activated successfully.
    """
    return f'{feature_name.capitalize()} activated successfully.'