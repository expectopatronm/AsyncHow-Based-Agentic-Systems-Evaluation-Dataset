def find_nearest_police_checkpoint(self, route):
    """
    Finds the nearest police checkpoint on the specified route.

    Args:
        route (str): The route on which to find the nearest police checkpoint.

    Returns:
        str: Confirmation message indicating the nearest police checkpoint was found successfully.
    """
    return f'Nearest police checkpoint on route {route} found successfully.'