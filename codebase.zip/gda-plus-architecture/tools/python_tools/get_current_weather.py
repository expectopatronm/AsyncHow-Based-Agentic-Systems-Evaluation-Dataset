# Auto-generated Python script
def get_current_weather(self, city):
    """
    Fetches the current weather including temperature, weather conditions, precipitation chance, sunrise and sunset.
    
    Parameters:
    city (str): The name of the city for which to fetch the weather.
    
    Returns:
    dict: A dictionary containing the current weather data for the specified city.
    """
    import requests

    BASE_URL = "https://agreeable-water-09f0b7103.5.azurestaticapps.net/weather"

    params = {
        'location': city,
        'destination': '',
        'path': []
    }

    response = requests.get(BASE_URL, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error: {response.status_code}")

        dummy_resp = """{
                        "temperature": {
                            "high": 24,
                            "low": 18
                        },
                        "weather_conditions": "wolkig",
                        "precipitation_chance": 35,
                        "sunrise": "2024-08-05T05:54:52+02:00",
                        "sunset": "2024-08-05T20:43:12+02:00"
                    }
            
        """
        return dummy_resp
