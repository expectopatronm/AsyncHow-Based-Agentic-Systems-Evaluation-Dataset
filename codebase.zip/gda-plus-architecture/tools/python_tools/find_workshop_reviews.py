def find_workshop_reviews(self, workshop_name, country=None):
    """
    Finds reviews of the specified workshop, optionally in a specific country.

    Args:
        workshop_name (str): The name of the workshop to find reviews for.
        country (str, optional): The country where the workshop is located.

    Returns:
        str: Confirmation message indicating the workshop reviews were found successfully.
    """
    if country:
        return f'Reviews for {workshop_name} in {country} found successfully.'
    else:
        return f'Reviews for {workshop_name} found successfully.'