def calculate_toll_to_destination(self, destination):
    """
    Calculates the toll cost to the specified destination.

    Args:
        destination (str): The destination for which the toll cost is to be calculated.

    Returns:
        str: Confirmation message indicating the toll cost calculation was successful.
    """
    return f'Toll cost to {destination} calculated successfully.'