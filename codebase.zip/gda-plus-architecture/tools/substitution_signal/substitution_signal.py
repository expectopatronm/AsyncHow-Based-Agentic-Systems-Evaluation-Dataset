def substitution_signal(input_1, input_2):
    """
    Mimics the action of sideline referees making a rectangle for a substitution.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A description of the substitution signal.
    """
    return "The sideline referees hold their arms up and form a rectangle shape to indicate a substitution."
