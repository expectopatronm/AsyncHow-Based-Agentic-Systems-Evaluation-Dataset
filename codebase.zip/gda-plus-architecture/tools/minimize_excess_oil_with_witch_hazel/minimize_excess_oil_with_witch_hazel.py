def minimize_excess_oil_with_witch_hazel(input_1, input_2):
    """
    Mimics the minimization of excess oil with a witch hazel lotion or toner.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Witch hazel lotion applied. Excess oil reduced by 35%."
