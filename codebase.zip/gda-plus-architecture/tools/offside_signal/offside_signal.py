def offside_signal(input_1, input_2):
    """
    Mimics the action of a referee stopping and pointing their flag for an offside.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: A description of the offside signal.
    """
    return "The referee stops play and raises their flag horizontally to indicate an offside infraction."
