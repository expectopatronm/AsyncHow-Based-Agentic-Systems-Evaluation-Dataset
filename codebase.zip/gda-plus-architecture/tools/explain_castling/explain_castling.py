def explain_castling(input_1, input_2):
    """
    Detailed description of what the function does

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Castling is a special move involving the king and either rook. The king moves two squares towards the rook, and the rook moves to the square next to the king. This move can only be done if neither piece has moved before, there are no pieces between them, and the king is not in check."
