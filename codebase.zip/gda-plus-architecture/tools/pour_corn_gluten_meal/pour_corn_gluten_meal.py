def pour_corn_gluten_meal(input_1, input_2):
    """
    Mimics the pouring of corn-gluten meal into the compost.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Confirmation message indicating corn-gluten meal has been poured.
    """
    return 'Corn-gluten meal has been poured into the compost.'
