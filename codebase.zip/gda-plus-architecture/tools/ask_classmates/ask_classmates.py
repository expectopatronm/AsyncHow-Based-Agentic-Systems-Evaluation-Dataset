def ask_classmates(input_1, input_2):
    """
    Provides a list of classmates who are available to help with the subject.

    Args:
        input_1(str): The subject for which help is needed.
        input_2 (bool): Whether to include classmates who prefer online communication.

    Returns:
        str: A JSON string containing details about classmates, including names and contact information.
    """
    import json
    data = {
        "classmates": [
            {"name": "Alice Johnson", "contact": "alice.johnson@example.com"},
            {"name": "Bob Smith", "contact": "bob.smith@example.com"}
        ]
    }
    return json.dumps(data)
