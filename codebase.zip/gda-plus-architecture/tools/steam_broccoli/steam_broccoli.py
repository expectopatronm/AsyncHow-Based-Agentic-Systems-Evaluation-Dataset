def steam_broccoli(input_1, input_2):
    """
    Provides instructions for steaming broccoli using a steamer basket or microwave.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Instructions for steaming broccoli.
    """
    return "Steamed Broccoli: Place broccoli florets in a steamer basket over boiling water, cover, and steam for 5-7 minutes until tender. Alternatively, microwave broccoli in a covered dish with a little water for 3-4 minutes."
