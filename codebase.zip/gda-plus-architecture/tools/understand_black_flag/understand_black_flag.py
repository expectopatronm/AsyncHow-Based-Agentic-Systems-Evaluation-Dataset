def understand_black_flag(input_1, input_2):
    """
    Detailed description of what the function does

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "The black flag in NASCAR indicates a driver must go to the pits, usually due to a rule violation."
