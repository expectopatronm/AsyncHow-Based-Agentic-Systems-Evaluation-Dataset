def do_side_squats(input_1, input_2):
    """
    Mimics the action of performing side squats and returns a description of the exercise.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Side squats target the hips, glutes, and thighs. Stand with feet shoulder-width apart, step to the side with one leg, and squat down while keeping the other leg straight."
