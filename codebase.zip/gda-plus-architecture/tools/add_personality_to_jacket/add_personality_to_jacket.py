def add_personality_to_jacket(input_1, input_2):
    """
    Add personality to a jacket or blazer by pinning a brooch to the lapel.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Detailed explanation of what the function returns.
    """
    return "Add personality to a jacket or blazer by pinning a brooch to the lapel, creating a unique look."
