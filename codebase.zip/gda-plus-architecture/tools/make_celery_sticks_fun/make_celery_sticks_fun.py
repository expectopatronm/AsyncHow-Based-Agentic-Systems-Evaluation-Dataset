def make_celery_sticks_fun(input_1, input_2):
    """
    Suggest ways to make celery sticks fun for kids.

    Args:
        input_1(str): Detailed description of the first input parameter.
        input_2 (bool): Detailed description of the second input parameter.

    Returns:
        str: Fun ideas for celery sticks.
    """
    return "Fill celery sticks with peanut butter or cream cheese. Top with raisins or sliced almonds."
