import os
import sys
from queue import Queue

# Get the directory of the current script
script_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')

# Add the directory to sys.path
sys.path.append(script_dir)


class FeedbackSystem:
    def __init__(self, my_gpt_client_manager):

        self.client = my_gpt_client_manager.openai_client
        self.deployment_name = my_gpt_client_manager.model_name

        self.task_execution_metadata = Queue()
        self.phrases_cache = []

    def clear_cache(self):
        """Clear the Queue and phrases_cache."""

        with self.task_execution_metadata.mutex:
            self.task_execution_metadata.queue.clear()
        self.phrases_cache = []

    def _generate_feedback_phrase(self, task_description):
        prompt = """
        You are responsible for generating a short feedback phrase to display to the user while they are waiting for a specific task to be executed. 
        The phrase should be concise, friendly, and reassuring, letting the user know that their task is in progress.
        Make sure the feedback phrase is not one of the following previously used phrases:
        {previous_phrases}

        Task: {task_description}

        Generate a new feedback phrase to show the user while this task is being processed, ensuring it’s different from the previously used ones.
        """

        message = [{"role": "user",
                    "content": prompt.format(task_description=task_description, previous_phrases=self.phrases_cache)}]
        response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=message,
        )
        self.phrases_cache.append(response.choices[0].message.content)
        return response.choices[0].message.content

    def add_to_queue(self, task_id, label):
        # Feedback
        self.task_execution_metadata.put({
            "task_id": task_id,
            "task_label": label,
            "execution_status": "Started",
            "feedback_phrase": self._generate_feedback_phrase(label)
        })
